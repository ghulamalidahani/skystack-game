/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Copy, Check, Download, Share2, Sparkles } from 'lucide-react';
import { sound } from '../game/sound';

interface ShareModalProps {
  score: number;
  maxCombo: number;
  perfectCount: number;
  screenshotUrl: string | null;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  score,
  maxCombo,
  perfectCount,
  screenshotUrl,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);

  const accuracy = score > 0 ? Math.round((perfectCount / score) * 100) : 0;

  const shareText = `🗼 I stacked to Floor ${score} in SkyStack 3D!
🔥 Max Combo: ${maxCombo}x Perfect Streak
🎯 Precision: ${accuracy}%
Can you build higher? Play now!
🧱✨
🟪🟪
🟦🟦🟦
🟩🟩🟩
🟨🟨🟨🟨
#SkyStack3D #ArcadeGame #Highscore`;

  const handleCopyText = async () => {
    sound.playClick();
    try {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleNativeShare = async () => {
    sound.playClick();
    if (typeof navigator !== 'undefined' && 'share' in navigator) {
      try {
        await navigator.share({
          title: 'SkyStack 3D High Score',
          text: shareText,
          url: window.location.href,
        });
      } catch {
        // User cancelled share
      }
    } else {
      handleCopyText();
    }
  };

  const handleDownloadImage = () => {
    sound.playClick();
    if (!screenshotUrl) return;
    const a = document.createElement('a');
    a.href = screenshotUrl;
    a.download = `skystack-floor-${score}.png`;
    a.click();
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 select-none">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 flex flex-col items-center animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between w-full mb-4">
          <div className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Share Your Tower
            </h3>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1 rounded-full text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 3D Screenshot Preview Card */}
        <div className="w-full aspect-[4/3] rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 relative mb-4 flex items-center justify-center shadow-inner">
          {screenshotUrl ? (
            <img
              src={screenshotUrl}
              alt="Tower Screenshot"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="text-xs text-slate-500 flex flex-col items-center gap-1">
              <Sparkles className="w-6 h-6 text-sky-400" />
              <span>Tower Snapshot</span>
            </div>
          )}

          {/* Watermark overlay badge */}
          <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between px-2.5 py-1.5 rounded-xl bg-slate-900/85 border border-slate-700/60 backdrop-blur-none text-left">
            <div>
              <div className="text-[10px] font-bold text-slate-400">SKYSTACK 3D</div>
              <div className="text-xs font-black text-white">Floor {score} · {maxCombo}x Streak</div>
            </div>
            <div className="text-lg">🗼</div>
          </div>
        </div>

        {/* Share Actions */}
        <div className="flex flex-col gap-2.5 w-full">
          {/* Native Web Share (if supported) */}
          {'share' in navigator && (
            <button
              onClick={handleNativeShare}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold text-xs tracking-wide shadow-md active:scale-95 transition-all"
            >
              <Share2 className="w-4 h-4" />
              <span>Share to Social / Apps</span>
            </button>
          )}

          {/* Copy Post Button */}
          <button
            onClick={handleCopyText}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-slate-800 border border-slate-700 hover:bg-slate-700 text-white font-bold text-xs tracking-wide active:scale-95 transition-all"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-300">Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-sky-400" />
                <span>Copy Stats & Emojis</span>
              </>
            )}
          </button>

          {/* Download Image Button */}
          {screenshotUrl && (
            <button
              onClick={handleDownloadImage}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 font-semibold text-xs active:scale-95 transition-all"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span>Download Screenshot PNG</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
