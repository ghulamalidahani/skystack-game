/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, RotateCcw, Home, Volume2, VolumeX, Vibrate, HelpCircle } from 'lucide-react';
import { sound } from '../game/sound';

interface PauseModalProps {
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  onToggleSound: () => void;
  onToggleHaptics: () => void;
  onResume: () => void;
  onRestart: () => void;
  onGoHome: () => void;
  onOpenTutorial: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  soundEnabled,
  hapticsEnabled,
  onToggleSound,
  onToggleHaptics,
  onResume,
  onRestart,
  onGoHome,
  onOpenTutorial,
}) => {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85 select-none">
      <div className="w-full max-w-xs rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200">
        {/* Header with Title and Tutorial Button */}
        <div className="w-full flex items-center justify-between mb-5">
          <div className="w-8" /> {/* Balance spacer */}
          <h3 className="text-sm font-extrabold text-white uppercase tracking-widest">
            GAME PAUSED
          </h3>
          <button
            onClick={() => {
              sound.playClick();
              onOpenTutorial();
            }}
            className="w-8 h-8 rounded-full bg-slate-800/80 border border-slate-700/60 text-slate-300 hover:text-white flex items-center justify-center transition-all active:scale-95 shadow"
            title="How to Play"
            aria-label="How to play"
          >
            <HelpCircle className="w-4 h-4 text-sky-400" />
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 w-full mb-5">
          <button
            onClick={() => {
              sound.playClick();
              onResume();
            }}
            className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white font-extrabold text-xs tracking-wider shadow-lg shadow-sky-500/25 active:scale-95 transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>RESUME</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onRestart();
            }}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs tracking-wider border border-slate-700 active:scale-95 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-sky-400" />
            <span>RESTART</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onGoHome();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-slate-850 hover:bg-slate-800 text-slate-400 hover:text-slate-200 font-semibold text-xs border border-slate-800 active:scale-95 transition-all cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>MAIN MENU</span>
          </button>
        </div>

        {/* Audio / Haptic Settings row */}
        <div className="flex items-center gap-2.5 mb-5">
          <button
            onClick={onToggleSound}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold transition-all active:scale-95 ${
              soundEnabled
                ? 'bg-sky-500/10 border-sky-500/40 text-sky-400'
                : 'bg-slate-800 border-slate-700 text-slate-500'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span>Sound</span>
          </button>

          <button
            onClick={onToggleHaptics}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold transition-all active:scale-95 ${
              hapticsEnabled
                ? 'bg-teal-500/10 border-teal-500/40 text-teal-400'
                : 'bg-slate-800 border-slate-700 text-slate-500'
            }`}
          >
            <Vibrate className="w-3.5 h-3.5" />
            <span>Haptics</span>
          </button>
        </div>

        {/* Quick Controls Reminder at the bottom */}
        <div className="w-full pt-3 border-t border-slate-800/80">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">
            Quick Keys
          </div>
          <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 font-medium">
            <span className="font-mono bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">Esc / P</span>
            <span>Resume</span>
            <span className="text-slate-600">·</span>
            <span className="font-mono bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">R</span>
            <span>Restart</span>
          </div>
        </div>
      </div>
    </div>
  );
};
