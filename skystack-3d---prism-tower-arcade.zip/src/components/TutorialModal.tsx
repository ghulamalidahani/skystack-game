/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Sparkles, Gamepad2, Play, RotateCcw, Pause, Trophy, Layers } from 'lucide-react';
import { sound } from '../game/sound';

interface TutorialModalProps {
  onClose: () => void;
}

export const TutorialModal: React.FC<TutorialModalProps> = ({ onClose }) => {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 select-none">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 flex flex-col items-center animate-in fade-in zoom-in-95 duration-200 text-left">
        {/* Header */}
        <div className="flex items-center justify-between w-full mb-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center">
              <Gamepad2 className="w-4 h-4 text-sky-400" />
            </div>
            <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
              HOW TO PLAY
            </h3>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Goal Card */}
        <div className="w-full p-3.5 mb-4 rounded-2xl bg-gradient-to-r from-sky-500/15 via-indigo-500/15 to-purple-500/15 border border-sky-500/30">
          <div className="flex items-center gap-1.5 text-xs font-bold text-sky-300 mb-1">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>The Objective</span>
          </div>
          <p className="text-[12px] text-slate-200 leading-relaxed">
            Stack moving blocks perfectly to build the tallest prism tower. Any overhang is sliced off! Reach <span className="font-extrabold text-amber-300">5x Perfect Combos</span> to trigger <span className="text-emerald-300 font-extrabold">Mastery (+Expand)</span> and grow your block size back!
          </p>
        </div>

        {/* Controls Section */}
        <div className="w-full mb-5">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 px-1">
            Game Controls
          </div>

          <div className="space-y-2 text-xs">
            {/* TAP / SPACE */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400">
                  <Play className="w-3.5 h-3.5 fill-current" />
                </div>
                <span className="font-semibold text-slate-200">Place / Drop Block</span>
              </div>
              <div className="flex items-center gap-1 font-mono text-[11px] font-bold text-sky-300 bg-slate-900 px-2 py-1 rounded-md border border-slate-700">
                <span>TAP</span>
                <span className="text-slate-500">/</span>
                <span>SPACE</span>
              </div>
            </div>

            {/* P / ESC */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                  <Pause className="w-3.5 h-3.5" />
                </div>
                <span className="font-semibold text-slate-200">Pause / Resume</span>
              </div>
              <div className="flex items-center gap-1 font-mono text-[11px] font-bold text-amber-300 bg-slate-900 px-2 py-1 rounded-md border border-slate-700">
                <span>P</span>
                <span className="text-slate-500">/</span>
                <span>ESC</span>
              </div>
            </div>

            {/* R / ENTER */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400">
                  <RotateCcw className="w-3.5 h-3.5" />
                </div>
                <span className="font-semibold text-slate-200">Quick Restart</span>
              </div>
              <div className="flex items-center gap-1 font-mono text-[11px] font-bold text-rose-300 bg-slate-900 px-2 py-1 rounded-md border border-slate-700">
                <span>R</span>
                <span className="text-slate-500">/</span>
                <span>ENTER</span>
              </div>
            </div>
          </div>
        </div>

        {/* Pro Tip */}
        <div className="w-full flex items-center gap-2 p-2.5 rounded-xl bg-slate-800/30 border border-slate-800 mb-5 text-[11px] text-slate-400">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Tip: Align precisely with the floor below to hear harmonic musical scale notes and ignite combos!</span>
        </div>

        {/* Action Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-sky-500 via-indigo-500 to-pink-500 text-white font-extrabold text-xs tracking-wider shadow-lg active:scale-95 transition-all cursor-pointer text-center"
        >
          LET'S PLAY!
        </button>
      </div>
    </div>
  );
};
