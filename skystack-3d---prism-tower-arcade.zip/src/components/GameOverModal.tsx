/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Share2, Trophy, Palette, Flame, Target, Award, Sparkles, Home } from 'lucide-react';
import { sound } from '../game/sound';

interface GameOverModalProps {
  score: number;
  highScore: number;
  maxCombo: number;
  perfectCount: number;
  isNewHigh: boolean;
  unlockedList: string[];
  onRestart: () => void;
  onGoHome: () => void;
  onShare: () => void;
  onOpenLeaderboard: () => void;
  onOpenThemes: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  maxCombo,
  perfectCount,
  isNewHigh,
  unlockedList,
  onRestart,
  onGoHome,
  onShare,
  onOpenLeaderboard,
  onOpenThemes,
}) => {
  const [canRestart, setCanRestart] = useState(false);

  useEffect(() => {
    // 350ms debounce so the tap that broke the tower doesn't instantly restart
    const timer = setTimeout(() => {
      setCanRestart(true);
    }, 350);

    if (isNewHigh && score > 0) {
      try {
        confetti({
          particleCount: 70,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#38bdf8', '#fb923c', '#f43f5e', '#a855f7', '#facc15'],
        });
      } catch {
        // Ignore
      }
    }

    return () => clearTimeout(timer);
  }, [isNewHigh, score]);

  const accuracy = score > 0 ? Math.round((perfectCount / score) * 100) : 0;
  const isMobile =
    typeof window !== 'undefined' &&
    ('ontouchstart' in window || navigator.maxTouchPoints > 0);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (!canRestart) return;
    const target = e.target as HTMLElement;
    // If user clicked any interactive button, let the button handle it
    if (target.closest('button, a, input, select, textarea, [data-interactive="true"]')) {
      return;
    }
    sound.playClick();
    onRestart();
  };

  return (
    <div
      onClick={handleBackdropClick}
      className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-slate-950/80 select-none cursor-pointer"
      title="Click or Tap anywhere to restart"
    >
      <div
        onClick={(e) => {
          // If clicking card background itself (outside buttons), trigger restart too if ready
          const target = e.target as HTMLElement;
          if (!target.closest('button, a, input, select, textarea, [data-interactive="true"]')) {
            if (canRestart) {
              sound.playClick();
              onRestart();
            }
          }
        }}
        className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200 cursor-default"
      >
        {/* Top Header Row with Home Button & Title Badge */}
        <div className="w-full flex items-center justify-between mb-3">
          <button
            onClick={(e) => {
              e.stopPropagation();
              sound.playClick();
              onGoHome();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-800/90 border border-slate-700/80 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-700 transition-all active:scale-95 shadow cursor-pointer"
            title="Return to Main Menu"
            data-interactive="true"
          >
            <Home className="w-3.5 h-3.5 text-sky-400" />
            <span>Menu</span>
          </button>

          {isNewHigh ? (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-extrabold text-xs uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>NEW HIGH SCORE!</span>
            </div>
          ) : (
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest px-2">
              GAME OVER
            </div>
          )}

          <div className="w-16" /> {/* Balance spacer */}
        </div>

        {/* Big Score Readout */}
        <div className="text-6xl font-black text-white tracking-tight tabular-nums mb-1">
          {score}
        </div>
        <div className="text-xs font-medium text-slate-400 mb-5">
          {isNewHigh ? 'Your New Peak Height' : `Personal Record: ${highScore}`}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-2.5 w-full mb-5">
          <div className="flex flex-col items-center p-2.5 rounded-2xl bg-slate-800/60 border border-slate-700/50">
            <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-400 mb-0.5">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Max Combo</span>
            </div>
            <div className="text-lg font-black text-white tabular-nums">
              {maxCombo}x
            </div>
          </div>

          <div className="flex flex-col items-center p-2.5 rounded-2xl bg-slate-800/60 border border-slate-700/50">
            <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-400 mb-0.5">
              <Target className="w-3.5 h-3.5 text-sky-400" />
              <span>Perfect Rate</span>
            </div>
            <div className="text-lg font-black text-white tabular-nums">
              {accuracy}%
            </div>
          </div>
        </div>

        {/* Unlocked Notification Banner */}
        {unlockedList.length > 0 && (
          <div className="w-full mb-4 p-3 rounded-2xl bg-gradient-to-r from-amber-500/20 via-pink-500/20 to-purple-500/20 border border-amber-500/40 flex items-center gap-2.5 text-left">
            <Award className="w-5 h-5 text-amber-400 shrink-0" />
            <div className="text-xs text-amber-200">
              <div className="font-bold">Reward Unlocked!</div>
              <div className="text-amber-100/90 text-[11px] truncate">
                {unlockedList.join(', ')}
              </div>
            </div>
          </div>
        )}

        {/* Primary Action: Play Again & Clickable Tap to Restart Prompt */}
        <div className="w-full mb-3.5">
          <button
            onClick={(e) => {
              e.stopPropagation();
              sound.playClick();
              onRestart();
            }}
            className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white font-extrabold text-sm tracking-wide shadow-lg shadow-sky-500/25 hover:shadow-sky-500/40 active:scale-95 transition-all cursor-pointer"
            data-interactive="true"
          >
            <RotateCcw className="w-4 h-4" />
            <span>PLAY AGAIN</span>
          </button>

          {/* Interactive Tap Anywhere to Restart banner */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              sound.playClick();
              onRestart();
            }}
            className="mt-2 w-full py-1.5 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold tracking-wider active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5 animate-soft-pulse"
            title="Tap to restart game"
            data-interactive="true"
          >
            <span>👉 {isMobile ? 'Tap anywhere to Restart' : 'Press SPACE or Tap to Restart'}</span>
          </button>
        </div>

        {/* Secondary Action Grid (4 columns: Home, Share, Ranks, Skins) */}
        <div className="grid grid-cols-4 gap-2 w-full">
          <button
            onClick={(e) => {
              e.stopPropagation();
              sound.playClick();
              onGoHome();
            }}
            className="flex flex-col items-center justify-center gap-1 py-2.5 px-1.5 rounded-xl bg-slate-800/80 border border-slate-700 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-all active:scale-95 cursor-pointer"
            title="Main Menu"
            data-interactive="true"
          >
            <Home className="w-4 h-4 text-sky-400" />
            <span className="text-[11px]">Home</span>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              sound.playClick();
              onShare();
            }}
            className="flex flex-col items-center justify-center gap-1 py-2.5 px-1.5 rounded-xl bg-slate-800/80 border border-slate-700 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-all active:scale-95 cursor-pointer"
            title="Share Score"
            data-interactive="true"
          >
            <Share2 className="w-4 h-4 text-emerald-400" />
            <span className="text-[11px]">Share</span>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              sound.playClick();
              onOpenLeaderboard();
            }}
            className="flex flex-col items-center justify-center gap-1 py-2.5 px-1.5 rounded-xl bg-slate-800/80 border border-slate-700 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-all active:scale-95 cursor-pointer"
            title="Leaderboard"
            data-interactive="true"
          >
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-[11px]">Ranks</span>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              sound.playClick();
              onOpenThemes();
            }}
            className="flex flex-col items-center justify-center gap-1 py-2.5 px-1.5 rounded-xl bg-slate-800/80 border border-slate-700 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-all active:scale-95 cursor-pointer"
            title="Themes & Styles"
            data-interactive="true"
          >
            <Palette className="w-4 h-4 text-pink-400" />
            <span className="text-[11px]">Skins</span>
          </button>
        </div>
      </div>
    </div>
  );
};
