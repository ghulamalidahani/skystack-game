/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Palette, Box, Check, Lock, Sparkles, Award } from 'lucide-react';
import { THEMES } from '../game/themes';
import { ThemeId, BlockMaterialStyle } from '../game/types';
import { INITIAL_CHALLENGES } from '../game/storage';
import { sound } from '../game/sound';

interface ThemeShopModalProps {
  activeTheme: ThemeId;
  activeStyle: BlockMaterialStyle;
  unlockedThemes: ThemeId[];
  unlockedStyles: BlockMaterialStyle[];
  highScore: number;
  totalStacked: number;
  highestCombo: number;
  onSelectTheme: (theme: ThemeId) => void;
  onSelectStyle: (style: BlockMaterialStyle) => void;
  onClose: () => void;
}

const STYLES_INFO: Array<{
  id: BlockMaterialStyle;
  name: string;
  description: string;
  requirement: string;
}> = [
  {
    id: 'glossy',
    name: 'Glossy Lacquer',
    description: 'Smooth clean reflections with standard specular highlights',
    requirement: 'Default',
  },
  {
    id: 'crystal',
    name: 'Prism Crystal',
    description: 'Translucent refractive glass with clearcoat shimmer',
    requirement: 'Score 20 or Hit 4x Perfect Streak',
  },
  {
    id: 'metallic',
    name: 'Polished Chrome',
    description: 'High-metalness mirrored surfaces reflecting the studio room',
    requirement: 'Score 40 or Stack 100 total blocks',
  },
  {
    id: 'matte',
    name: 'Matte Clay',
    description: 'Soft non-reflective architectural minimalism',
    requirement: 'Score 10 in any game',
  },
  {
    id: 'neon',
    name: 'Neon Glow Core',
    description: 'Vivid self-illuminated electric emissive light',
    requirement: 'Score 70 or Hit 6x Perfect Streak',
  },
];

export const ThemeShopModal: React.FC<ThemeShopModalProps> = ({
  activeTheme,
  activeStyle,
  unlockedThemes,
  unlockedStyles,
  highScore,
  totalStacked,
  highestCombo,
  onSelectTheme,
  onSelectStyle,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'themes' | 'styles' | 'challenges'>('themes');

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85 select-none">
      <div className="w-full max-w-md h-[580px] rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Palette className="w-5 h-5 text-pink-400" />
            <h2 className="text-base font-extrabold text-white tracking-wide">
              SKINS & PALETTES
            </h2>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 3-Tab Navigator */}
        <div className="grid grid-cols-3 p-1.5 m-4 mb-2 rounded-2xl bg-slate-950/60 border border-slate-800/60">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('themes');
            }}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'themes'
                ? 'bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Themes</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('styles');
            }}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'styles'
                ? 'bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>Materials</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('challenges');
            }}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'challenges'
                ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Rewards</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2.5">
          {/* TAB 1: THEMES */}
          {activeTab === 'themes' &&
            Object.values(THEMES).map((theme) => {
              const isUnlocked = unlockedThemes.includes(theme.id) || theme.unlockFloor === 0;
              const isSelected = activeTheme === theme.id;

              return (
                <div
                  key={theme.id}
                  onClick={() => {
                    if (isUnlocked) {
                      sound.playClick();
                      onSelectTheme(theme.id);
                    }
                  }}
                  className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                    isSelected
                      ? 'bg-pink-500/10 border-pink-500/60 ring-1 ring-pink-500/40 cursor-default'
                      : isUnlocked
                      ? 'bg-slate-800/60 border-slate-700 hover:bg-slate-800 cursor-pointer'
                      : 'bg-slate-900/60 border-slate-800/80 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {/* Color Swatches */}
                    <div className="flex -space-x-1.5">
                      {theme.colorPalette.slice(0, 4).map((c, i) => (
                        <div
                          key={i}
                          className="w-5 h-5 rounded-full border border-slate-900 shadow-sm"
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>

                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span>{theme.name}</span>
                        {isSelected && (
                          <span className="text-[10px] font-bold text-pink-400 bg-pink-500/20 px-1.5 py-0.2 rounded-full">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {theme.description}
                      </div>
                    </div>
                  </div>

                  <div>
                    {isSelected ? (
                      <div className="p-1.5 rounded-full bg-pink-500 text-white">
                        <Check className="w-4 h-4" />
                      </div>
                    ) : isUnlocked ? (
                      <span className="text-xs font-bold text-slate-300 hover:text-white">
                        Equip
                      </span>
                    ) : (
                      <div className="flex items-center gap-1 text-[11px] font-semibold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20">
                        <Lock className="w-3 h-3" />
                        <span>Floor {theme.unlockFloor}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

          {/* TAB 2: BLOCK MATERIALS */}
          {activeTab === 'styles' &&
            STYLES_INFO.map((style) => {
              const isUnlocked = unlockedStyles.includes(style.id) || style.id === 'glossy';
              const isSelected = activeStyle === style.id;

              return (
                <div
                  key={style.id}
                  onClick={() => {
                    if (isUnlocked) {
                      sound.playClick();
                      onSelectStyle(style.id);
                    }
                  }}
                  className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                    isSelected
                      ? 'bg-sky-500/10 border-sky-500/60 ring-1 ring-sky-500/40 cursor-default'
                      : isUnlocked
                      ? 'bg-slate-800/60 border-slate-700 hover:bg-slate-800 cursor-pointer'
                      : 'bg-slate-900/60 border-slate-800/80 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-sm text-sky-400">
                      <Box className="w-4 h-4" />
                    </div>

                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span>{style.name}</span>
                        {isSelected && (
                          <span className="text-[10px] font-bold text-sky-400 bg-sky-500/20 px-1.5 py-0.2 rounded-full">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {style.description}
                      </div>
                    </div>
                  </div>

                  <div>
                    {isSelected ? (
                      <div className="p-1.5 rounded-full bg-sky-500 text-white">
                        <Check className="w-4 h-4" />
                      </div>
                    ) : isUnlocked ? (
                      <span className="text-xs font-bold text-slate-300 hover:text-white">
                        Equip
                      </span>
                    ) : (
                      <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-400 bg-slate-800 px-2.5 py-1 rounded-full border border-slate-700">
                        <Lock className="w-3 h-3" />
                        <span>Locked</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

          {/* TAB 3: CHALLENGES & REWARDS */}
          {activeTab === 'challenges' &&
            INITIAL_CHALLENGES.map((ch) => {
              let currentVal = highScore;
              if (ch.id === 'c3') currentVal = highestCombo;
              if (ch.id === 'c7') currentVal = totalStacked;
              if (ch.id === 'c8') currentVal = Math.max(highScore, highestCombo * 10);

              const isComplete = currentVal >= ch.target;
              const progressPct = Math.min(100, Math.round((currentVal / ch.target) * 100));

              return (
                <div
                  key={ch.id}
                  className={`p-3.5 rounded-2xl border ${
                    isComplete
                      ? 'bg-amber-500/10 border-amber-500/30'
                      : 'bg-slate-800/50 border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      {isComplete && <Sparkles className="w-3.5 h-3.5 text-amber-400" />}
                      <span>{ch.title}</span>
                    </div>

                    <div className="text-[11px] font-bold tabular-nums text-slate-300">
                      {currentVal} / {ch.target}
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400 mb-2">
                    {ch.description}
                  </div>

                  {/* Progress bar */}
                  <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        isComplete ? 'bg-amber-400' : 'bg-sky-500'
                      }`}
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};
