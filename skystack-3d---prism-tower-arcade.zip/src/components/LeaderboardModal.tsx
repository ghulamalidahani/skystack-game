/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Trophy, History, User, Check } from 'lucide-react';
import { LeaderboardItem } from '../game/types';
import { GameRunRecord } from '../game/storage';
import { sound } from '../game/sound';

interface LeaderboardModalProps {
  items: LeaderboardItem[];
  history: GameRunRecord[];
  playerName: string;
  onUpdatePlayerName: (name: string) => void;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  items,
  history,
  playerName,
  onUpdatePlayerName,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'global' | 'history'>('global');
  const [editingName, setEditingName] = useState(false);
  const [tempName, setTempName] = useState(playerName);

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempName.trim()) {
      onUpdatePlayerName(tempName.trim().slice(0, 16));
      setEditingName(false);
    }
  };

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85 select-none">
      <div className="w-full max-w-md h-[560px] rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-extrabold text-white tracking-wide">
              LEADERBOARDS
            </h2>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Player Tag Row */}
        <div className="px-6 py-3 bg-slate-800/40 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs">
            <User className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-slate-400">Player:</span>
            {editingName ? (
              <form onSubmit={handleSaveName} className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  maxLength={16}
                  className="px-2 py-0.5 rounded bg-slate-800 border border-slate-600 text-white text-xs font-semibold focus:outline-none focus:border-sky-400"
                  autoFocus
                />
                <button
                  type="submit"
                  className="p-1 rounded bg-sky-500 text-white hover:bg-sky-400"
                >
                  <Check className="w-3 h-3" />
                </button>
              </form>
            ) : (
              <button
                onClick={() => setEditingName(true)}
                className="font-bold text-sky-300 hover:underline cursor-pointer"
                title="Click to rename"
              >
                {playerName} ✏️
              </button>
            )}
          </div>

          <div className="text-[11px] font-semibold text-slate-400">
            Simulated Global Ladder
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-2 p-1.5 m-4 mb-2 rounded-2xl bg-slate-950/60 border border-slate-800/60">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('global');
            }}
            className={`flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'global'
                ? 'bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>Global Ranks</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('history');
            }}
            className={`flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'history'
                ? 'bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Your Runs</span>
          </button>
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
          {activeTab === 'global' ? (
            items.map((item) => {
              const isTop3 = item.rank <= 3;
              const rankColor =
                item.rank === 1
                  ? 'text-amber-400 bg-amber-500/10 border-amber-500/30'
                  : item.rank === 2
                  ? 'text-slate-300 bg-slate-400/10 border-slate-400/30'
                  : item.rank === 3
                  ? 'text-amber-600 bg-amber-700/10 border-amber-700/30'
                  : 'text-slate-400 bg-slate-800/40 border-slate-800';

              return (
                <div
                  key={item.id}
                  className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                    item.isPlayer
                      ? 'bg-gradient-to-r from-sky-500/20 via-indigo-500/20 to-pink-500/20 border-sky-400/60 ring-1 ring-sky-400/40'
                      : 'bg-slate-800/50 border-slate-800/80'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs border ${rankColor}`}
                    >
                      {item.rank}
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-base">{item.avatar}</span>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`text-xs font-bold ${
                              item.isPlayer ? 'text-sky-300' : 'text-white'
                            }`}
                          >
                            {item.name}
                          </span>
                          <span className="text-xs">{item.country}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {item.badge}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-black text-white tabular-nums">
                      {item.score}
                    </div>
                    <div className="text-[10px] text-slate-500 font-medium">
                      floors
                    </div>
                  </div>
                </div>
              );
            })
          ) : history.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-6 text-slate-500 text-xs">
              <History className="w-8 h-8 mb-2 opacity-50" />
              <span>No runs recorded yet. Start stacking to build your record!</span>
            </div>
          ) : (
            history.map((run) => (
              <div
                key={run.id}
                className="flex items-center justify-between p-3 rounded-2xl bg-slate-800/50 border border-slate-800"
              >
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-2">
                    <span>Floor {run.score}</span>
                    <span className="text-[10px] font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">
                      {run.maxCombo}x combo
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {run.perfectHits} perfects · {run.date}
                  </div>
                </div>

                <div className="text-right text-xs font-bold text-sky-400 uppercase tracking-wider">
                  {run.theme}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
