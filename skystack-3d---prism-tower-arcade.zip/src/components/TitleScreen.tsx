/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, Trophy, Palette, Volume2, VolumeX, Sparkles, HelpCircle } from 'lucide-react';
import { sound } from '../game/sound';

interface TitleScreenProps {
  highScore: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onStartGame: () => void;
  onOpenLeaderboard: () => void;
  onOpenThemes: () => void;
  onOpenTutorial: () => void;
  activeThemeName: string;
  activeStyleName: string;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  highScore,
  soundEnabled,
  onToggleSound,
  onStartGame,
  onOpenLeaderboard,
  onOpenThemes,
  onOpenTutorial,
  activeThemeName,
  activeStyleName,
}) => {
  return (
    <div className="absolute inset-0 z-20 flex flex-col justify-between p-6 sm:p-10 select-none pointer-events-none">
      {/* Top Header Row */}
      <div className="flex items-center justify-between w-full pointer-events-auto">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/60 shadow-lg">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-amber-300 tabular-nums">
              RECORD: {highScore}
            </span>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onOpenTutorial();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900/80 border border-sky-500/40 text-slate-200 hover:text-white hover:border-sky-400 transition-all active:scale-95 shadow-lg cursor-pointer"
            title="How to Play"
            aria-label="How to play"
          >
            <HelpCircle className="w-4 h-4 text-sky-400" />
            <span className="text-xs font-bold text-sky-300">How to Play</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sound.playClick();
              onOpenThemes();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/60 text-xs font-semibold text-sky-300 shadow-lg active:scale-95 transition-all hover:bg-slate-800"
            title="Themes & Styles"
          >
            <Palette className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">{activeThemeName}</span>
          </button>

          <button
            onClick={onToggleSound}
            className={`p-2 rounded-full border shadow-lg transition-all active:scale-95 ${
              soundEnabled
                ? 'bg-slate-900/80 border-slate-700/60 text-sky-400'
                : 'bg-slate-900/40 border-slate-800 text-slate-500'
            }`}
            title={soundEnabled ? 'Mute' : 'Unmute'}
            aria-label="Toggle sound"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Center Hero Lockup with bespoke inline SVG Title */}
      <div className="flex flex-col items-center justify-center my-auto pointer-events-auto max-w-lg mx-auto w-full text-center">
        {/* Bespoke inline SVG Title Lockup */}
        <div className="w-full max-w-[340px] sm:max-w-[420px] mb-4">
          <svg viewBox="0 0 420 120" className="w-full h-auto drop-shadow-[0_8px_24px_rgba(0,0,0,0.7)]">
            <defs>
              <linearGradient id="titleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="50%" stopColor="#818cf8" />
                <stop offset="100%" stopColor="#ec4899" />
              </linearGradient>
              <linearGradient id="subGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#fbbf24" />
                <stop offset="100%" stopColor="#f59e0b" />
              </linearGradient>
            </defs>

            {/* Stylized 3D Prism isometric icon */}
            <g transform="translate(45, 20)">
              <polygon points="25,5 45,17 45,42 25,30" fill="#38bdf8" opacity="0.9" />
              <polygon points="25,5 5,17 5,42 25,30" fill="#818cf8" opacity="0.75" />
              <polygon points="25,5 45,17 25,30 5,17" fill="#c084fc" opacity="0.95" />
            </g>

            {/* Typography */}
            <text
              x="115"
              y="52"
              fill="url(#titleGrad)"
              fontFamily="system-ui, sans-serif"
              fontWeight="900"
              fontSize="44"
              letterSpacing="3"
            >
              SKYSTACK
            </text>
            <text
              x="368"
              y="44"
              fill="#f43f5e"
              fontFamily="system-ui, sans-serif"
              fontWeight="900"
              fontSize="20"
              letterSpacing="1"
            >
              3D
            </text>

            <text
              x="116"
              y="74"
              fill="url(#subGrad)"
              fontFamily="system-ui, sans-serif"
              fontWeight="800"
              fontSize="13"
              letterSpacing="5"
            >
              PRISM TOWER ARCADE
            </text>

            <line x1="116" y1="84" x2="390" y2="84" stroke="rgba(255,255,255,0.25)" strokeWidth="1.5" />
          </svg>
        </div>

        {/* Current style pill */}
        <div className="flex items-center gap-2 mb-6">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest bg-slate-900/80 px-3 py-1 rounded-full border border-slate-800">
            Style: <span className="text-white">{activeStyleName}</span>
          </span>
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest bg-slate-900/80 px-3 py-1 rounded-full border border-slate-800">
            Theme: <span className="text-white">{activeThemeName}</span>
          </span>
        </div>

        {/* Primary Start CTA Button */}
        <button
          onClick={() => {
            sound.playClick();
            onStartGame();
          }}
          className="group relative inline-flex items-center justify-center gap-3 w-full sm:w-72 px-8 py-4 rounded-2xl bg-gradient-to-r from-sky-500 via-indigo-500 to-pink-500 text-white font-extrabold text-lg tracking-wide shadow-[0_0_30px_rgba(56,189,248,0.4)] hover:shadow-[0_0_40px_rgba(236,72,153,0.6)] active:scale-95 transition-all transform hover:-translate-y-0.5 cursor-pointer"
        >
          <Play className="w-5 h-5 fill-current" />
          <span>PLAY NOW</span>
          <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
        </button>

        {/* Secondary Buttons Row */}
        <div className="flex items-center gap-3 mt-4 w-full sm:w-72 justify-center">
          <button
            onClick={() => {
              sound.playClick();
              onOpenLeaderboard();
            }}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-900/80 border border-slate-700/80 hover:bg-slate-800 text-xs font-bold text-slate-200 transition-all active:scale-95 shadow-md"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>Leaderboard</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenThemes();
            }}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-900/80 border border-slate-700/80 hover:bg-slate-800 text-xs font-bold text-slate-200 transition-all active:scale-95 shadow-md"
          >
            <Palette className="w-3.5 h-3.5 text-pink-400" />
            <span>Skins</span>
          </button>
        </div>
      </div>

      {/* Flat Single Control Hint Line */}
      <div className="flex flex-col items-center justify-center pb-2 pointer-events-none text-center">
        <p className="text-xs font-medium text-slate-400 tracking-wider">
          Space / Tap Action · Esc Pause · R Restart
        </p>
      </div>
    </div>
  );
};
