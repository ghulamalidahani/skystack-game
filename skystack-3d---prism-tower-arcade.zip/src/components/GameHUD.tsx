/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Pause, Trophy, Vibrate, Sparkles, Flame, CheckCircle2, Zap } from 'lucide-react';
import { getLevelInfo, LevelInfo } from '../game/difficulty';

export interface FloatingFeedback {
  id: number;
  type: 'perfect' | 'mastery';
  title: string;
  subText?: string;
}

export interface LevelBannerData {
  id: number;
  title: string;
  subtitle: string;
}

interface GameHUDProps {
  score: number;
  highScore: number;
  combo: number;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  onToggleSound: () => void;
  onToggleHaptics: () => void;
  onPause: () => void;
  onOpenLeaderboard: () => void;
  activeThemeName: string;
  feedback: FloatingFeedback | null;
  levelBanner: LevelBannerData | null;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  score,
  highScore,
  combo,
  soundEnabled,
  hapticsEnabled,
  onToggleSound,
  onToggleHaptics,
  onPause,
  onOpenLeaderboard,
  activeThemeName,
  feedback,
  levelBanner,
}) => {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      const hasTouch = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);
      const isMobileUA = typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod|Windows Phone/i.test(navigator.userAgent);
      setIsMobile(hasTouch || isMobileUA || (typeof window !== 'undefined' && window.innerWidth < 768));
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const isFirstBlock = score === 0;
  const currentLevel: LevelInfo = getLevelInfo(score + 1);

  return (
    <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-3 sm:p-5 pt-[max(0.75rem,env(safe-area-inset-top))] select-none">
      {/* 1. FIXED TOP HUD CONTAINER (Sits cleanly ABOVE 3D viewport) */}
      <div className="flex items-start justify-between w-full">
        {/* Left Cluster: High Score Record & Theme Badge */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={onOpenLeaderboard}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900/85 border border-slate-700/70 text-xs font-bold text-amber-400 shadow-xl active:scale-95 transition-all cursor-pointer backdrop-blur-md"
            title="View Leaderboard"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span className="tabular-nums">BEST: {highScore}</span>
          </button>

          <div className="hidden md:flex items-center px-2.5 py-1 rounded-full bg-slate-900/70 border border-slate-800 text-[11px] text-slate-300 font-semibold backdrop-blur-md">
            {activeThemeName}
          </div>
        </div>

        {/* Center Cluster: Prominent Floor Score & Current Level Subtitle */}
        <div className="flex flex-col items-center pointer-events-none">
          <div className="text-5xl sm:text-6xl font-black tracking-tight text-white drop-shadow-[0_4px_20px_rgba(0,0,0,0.9)] tabular-nums leading-none">
            {score}
          </div>

          <div className="mt-1 flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-slate-900/85 border border-sky-400/40 text-[11px] sm:text-xs font-extrabold text-sky-300 shadow-lg backdrop-blur-md">
            <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span>{currentLevel.name}</span>
            <span className="text-slate-500">·</span>
            <span className="text-slate-300 font-semibold">{currentLevel.subtitle}</span>
          </div>
        </div>

        {/* Right Cluster: Persistent Combo Badge, Audio, Haptics, Pause */}
        <div className="flex items-center gap-1.5 sm:gap-2 pointer-events-auto">
          {/* Combo Counter (Fixed in Top Right Corner) */}
          {combo > 0 && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/95 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg border border-amber-300 animate-pulse">
              <Flame className="w-3.5 h-3.5 fill-current text-slate-950" />
              <span>PERFECT x{combo}</span>
              {combo >= 5 && (
                <span className="text-[10px] bg-slate-950 text-amber-300 px-1.5 py-0.2 rounded-full font-black">
                  +EXPAND!
                </span>
              )}
            </div>
          )}

          <button
            onClick={onToggleHaptics}
            className={`p-2 rounded-full border transition-all active:scale-95 cursor-pointer backdrop-blur-md ${
              hapticsEnabled
                ? 'bg-slate-900/85 border-slate-700 text-teal-400'
                : 'bg-slate-900/50 border-slate-800 text-slate-500'
            }`}
            title={hapticsEnabled ? 'Haptics: ON' : 'Haptics: OFF'}
            aria-label="Toggle haptics"
          >
            <Vibrate className="w-4 h-4" />
          </button>

          <button
            onClick={onToggleSound}
            className={`p-2 rounded-full border transition-all active:scale-95 cursor-pointer backdrop-blur-md ${
              soundEnabled
                ? 'bg-slate-900/85 border-slate-700 text-sky-400'
                : 'bg-slate-900/50 border-slate-800 text-slate-500'
            }`}
            title={soundEnabled ? 'Mute Audio' : 'Unmute Audio'}
            aria-label="Toggle audio"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={onPause}
            className="p-2 rounded-full bg-slate-900/85 border border-slate-700 text-slate-300 hover:text-white transition-all active:scale-95 cursor-pointer shadow-md backdrop-blur-md"
            title="Pause Game (Esc / P)"
            aria-label="Pause game"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. FLOATING ANNOUNCEMENT & POP-UP LAYER (High up, away from blocks) */}
      <div className="absolute top-28 sm:top-32 left-0 right-0 flex flex-col items-center pointer-events-none z-20">
        {/* Level Up Announcement (Brief pop-up) */}
        {levelBanner && (
          <div
            key={levelBanner.id}
            className="animate-float-fade flex flex-col items-center justify-center"
          >
            <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-sky-500 via-indigo-600 to-purple-600 text-white font-black text-sm uppercase tracking-wider shadow-[0_0_30px_rgba(56,189,248,0.6)] border border-sky-300">
              <Zap className="w-4 h-4 text-amber-300 animate-bounce" />
              <span>{levelBanner.title}</span>
              <span className="text-xs bg-slate-950/70 px-2.5 py-0.5 rounded-full text-amber-300 font-bold">
                ({levelBanner.subtitle})
              </span>
            </div>
          </div>
        )}

        {/* In-Game Floating Feedback (Perfect Snap / Mastery) */}
        {feedback && !levelBanner && (
          <div
            key={feedback.id}
            className="animate-float-fade flex flex-col items-center justify-center"
          >
            {feedback.type === 'mastery' ? (
              <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-sky-500 text-slate-950 font-black text-sm uppercase tracking-wider shadow-[0_0_30px_rgba(16,185,129,0.8)] border border-emerald-300">
                <Sparkles className="w-4 h-4 text-amber-200 animate-spin" />
                <span>{feedback.title}</span>
                <span className="text-[11px] bg-slate-950 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                  {feedback.subText || '+GROW'}
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(251,191,36,0.7)] border border-amber-200">
                <CheckCircle2 className="w-3.5 h-3.5 fill-current" />
                <span>{feedback.title}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 3. BOTTOM ONBOARDING HINT */}
      <div className="flex flex-col items-center justify-center pb-4 pointer-events-none">
        <div
          className={`transition-all duration-700 transform ${
            isFirstBlock
              ? 'opacity-100 translate-y-0 scale-100'
              : 'opacity-0 translate-y-4 scale-95 pointer-events-none'
          }`}
        >
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/85 border border-sky-400/40 text-xs font-semibold text-sky-200 shadow-[0_0_20px_rgba(56,189,248,0.3)] animate-soft-pulse backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
            <span className="tracking-wide">
              {isMobile ? 'Tap to Drop' : 'Press SPACE to Drop'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
