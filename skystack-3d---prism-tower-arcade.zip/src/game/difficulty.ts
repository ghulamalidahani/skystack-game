/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface LevelInfo {
  level: number;
  name: string;
  subtitle: string;
  minFloor: number;
  maxFloor: number;
}

export const LEVELS: LevelInfo[] = [
  { level: 1, name: 'Level 1', subtitle: 'Warm Up', minFloor: 1, maxFloor: 5 },
  { level: 2, name: 'Level 2', subtitle: 'Getting Faster', minFloor: 6, maxFloor: 15 },
  { level: 3, name: 'Level 3', subtitle: 'Fast Pace', minFloor: 16, maxFloor: 25 },
  { level: 4, name: 'Level 4', subtitle: 'Hyper Speed', minFloor: 26, maxFloor: 40 },
  { level: 5, name: 'Level 5', subtitle: 'Grandmaster', minFloor: 41, maxFloor: 999 },
];

/**
 * Variable speed multiplier:
 * - Floor 1: 0.5x (gentle, onboarding warm-up)
 * - Floor 5: ~0.7x
 * - Floor 10: 1.0x (standard arcade tempo)
 * - Floor 20: 1.5x (fast, thrilling pace)
 * - Floor 30+: scales up to 2.2x
 */
export function getSpeedMultiplier(floor: number): number {
  if (floor <= 1) return 0.5;
  if (floor <= 5) return 0.5 + (floor - 1) * 0.05; // 0.5 -> 0.70
  if (floor <= 10) return 0.7 + (floor - 5) * 0.06; // 0.70 -> 1.0
  if (floor <= 20) return 1.0 + (floor - 10) * 0.05; // 1.0 -> 1.5
  return Math.min(2.25, 1.5 + (floor - 20) * 0.035); // 1.5 -> 2.25 max
}

/**
 * Variable snap tolerance:
 * - Floors 1 to 5: 0.17 (generous, easy to get perfect snaps and musical chimes)
 * - Floors 6 to 15: 0.11 (moderate, standard skill)
 * - Floors 16+: 0.068 (strict / hard mode precision)
 */
export function getPerfectTolerance(floor: number): number {
  if (floor <= 5) return 0.17;
  if (floor <= 15) return 0.11;
  return 0.068;
}

/**
 * Returns level / zone descriptor for a given floor
 */
export function getLevelInfo(floor: number): LevelInfo {
  const match = LEVELS.find((l) => floor >= l.minFloor && floor <= l.maxFloor);
  return match || LEVELS[LEVELS.length - 1];
}

/**
 * Checks if advancing to newFloor triggers a level increase
 */
export function checkLevelUp(prevFloor: number, newFloor: number): LevelInfo | null {
  const prevLevel = getLevelInfo(prevFloor);
  const newLevel = getLevelInfo(newFloor);
  if (newLevel.level > prevLevel.level) {
    return newLevel;
  }
  return null;
}
