/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { ThemeConfig, ThemeId, BlockMaterialStyle } from './types';

export const THEMES: Record<ThemeId, ThemeConfig> = {
  prism: {
    id: 'prism',
    name: 'Prism Spectrum',
    description: 'Vibrant chromatic rainbow shifting through spectrum hues',
    unlockFloor: 0,
    skyTop: '#131b2e',
    skyBottom: '#0a0d18',
    fogColor: '#0c111e',
    pedestalColor: '#1e293b',
    colorPalette: [
      '#f43f5e', // Rose
      '#fb923c', // Orange
      '#facc15', // Yellow
      '#4ade80', // Green
      '#38bdf8', // Sky
      '#818cf8', // Indigo
      '#c084fc', // Purple
      '#f472b6', // Pink
    ],
    accentColor: '#38bdf8',
  },
  sunset: {
    id: 'sunset',
    name: 'Sunset Horizon',
    description: 'Warm golden hour dusk melting into rich violet twilight',
    unlockFloor: 15,
    skyTop: '#2e1065',
    skyBottom: '#4c0519',
    fogColor: '#3b0764',
    pedestalColor: '#2e1065',
    colorPalette: [
      '#fb7185',
      '#f43f5e',
      '#e11d48',
      '#be123c',
      '#fb923c',
      '#f97316',
      '#ea580c',
      '#c026d3',
      '#9333ea',
    ],
    accentColor: '#fb923c',
  },
  cyberpunk: {
    id: 'cyberpunk',
    name: 'Cyberpunk 2099',
    description: 'High-contrast electric cyan, hot magenta and deep midnight',
    unlockFloor: 30,
    skyTop: '#050510',
    skyBottom: '#100b20',
    fogColor: '#0a0714',
    pedestalColor: '#12121a',
    colorPalette: [
      '#06b6d4',
      '#0891b2',
      '#3b82f6',
      '#6366f1',
      '#ec4899',
      '#d946ef',
      '#f43f5e',
      '#10b981',
    ],
    accentColor: '#ec4899',
  },
  emerald: {
    id: 'emerald',
    name: 'Emerald Grove',
    description: 'Lush jade, spring teal, and glowing forest bioluminescence',
    unlockFloor: 45,
    skyTop: '#064e3b',
    skyBottom: '#022c22',
    fogColor: '#022c22',
    pedestalColor: '#064e3b',
    colorPalette: [
      '#34d399',
      '#10b981',
      '#059669',
      '#14b8a6',
      '#0d9488',
      '#22c55e',
      '#16a34a',
      '#84cc16',
    ],
    accentColor: '#34d399',
  },
  obsidian: {
    id: 'obsidian',
    name: 'Obsidian & Gold',
    description: 'Ultra-luxurious dark volcanic stone adorned with molten gold',
    unlockFloor: 60,
    skyTop: '#18181b',
    skyBottom: '#09090b',
    fogColor: '#09090b',
    pedestalColor: '#1c1917',
    colorPalette: [
      '#eab308',
      '#f59e0b',
      '#d97706',
      '#b45309',
      '#ca8a04',
      '#fbbf24',
      '#fcd34d',
      '#d4af37',
    ],
    accentColor: '#eab308',
  },
  aurora: {
    id: 'aurora',
    name: 'Aurora Borealis',
    description: 'Etherial polar ribbons of glacial azure, teal, and violet',
    unlockFloor: 80,
    skyTop: '#031424',
    skyBottom: '#08253a',
    fogColor: '#051829',
    pedestalColor: '#0f2942',
    colorPalette: [
      '#38bdf8',
      '#2dd4bf',
      '#5eead4',
      '#818cf8',
      '#a78bfa',
      '#22d3ee',
      '#67e8f9',
    ],
    accentColor: '#5eead4',
  },
  candy: {
    id: 'candy',
    name: 'Candy Dream',
    description: 'Sweet pastel macarons, strawberry cream, and mint drizzle',
    unlockFloor: 100,
    skyTop: '#291b2e',
    skyBottom: '#1e1424',
    fogColor: '#221727',
    pedestalColor: '#36233d',
    colorPalette: [
      '#f472b6',
      '#fb7185',
      '#fbcfe8',
      '#c084fc',
      '#a5b4fc',
      '#67e8f9',
      '#fde047',
    ],
    accentColor: '#f472b6',
  },
};

/**
 * Calculates smooth gradient color for a block at given floor index
 */
export function getBlockColor(themeId: ThemeId, floorIndex: number): THREE.Color {
  const theme = THEMES[themeId] || THEMES.prism;
  const palette = theme.colorPalette;
  const cycleLength = 24; // Number of floors to cycle through entire palette
  const normalizedIndex = (floorIndex % cycleLength) / cycleLength;
  
  const paletteLen = palette.length;
  const scaled = normalizedIndex * paletteLen;
  const index1 = Math.floor(scaled) % paletteLen;
  const index2 = (index1 + 1) % paletteLen;
  const factor = scaled - Math.floor(scaled);

  const c1 = new THREE.Color(palette[index1]);
  const c2 = new THREE.Color(palette[index2]);
  return c1.lerp(c2, factor);
}

/**
 * Creates appropriate Three.js material based on chosen block style
 */
export function createBlockMaterial(
  style: BlockMaterialStyle,
  color: THREE.Color,
  isSoftwareGl: boolean
): THREE.Material {
  switch (style) {
    case 'crystal':
      return new THREE.MeshPhysicalMaterial({
        color,
        metalness: 0.1,
        roughness: 0.1,
        transmission: isSoftwareGl ? 0 : 0.65,
        transparent: true,
        opacity: isSoftwareGl ? 0.75 : 0.95,
        ior: 1.5,
        reflectivity: 0.9,
        clearcoat: 1.0,
        clearcoatRoughness: 0.1,
      });

    case 'metallic':
      return new THREE.MeshStandardMaterial({
        color,
        metalness: 0.92,
        roughness: 0.18,
      });

    case 'neon':
      return new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.45,
        roughness: 0.2,
        metalness: 0.3,
      });

    case 'matte':
      return new THREE.MeshStandardMaterial({
        color,
        metalness: 0.05,
        roughness: 0.75,
      });

    case 'glossy':
    default:
      return new THREE.MeshStandardMaterial({
        color,
        metalness: 0.25,
        roughness: 0.25,
      });
  }
}
