/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type GameState = 'title' | 'playing' | 'paused' | 'gameover';

export type Axis = 'x' | 'z';

export interface BlockData {
  id: number;
  position: [number, number, number];
  size: [number, number, number];
  colorHex: string;
  isPerfect?: boolean;
}

export interface FallingDebrisData {
  id: number;
  position: [number, number, number];
  size: [number, number, number];
  velocity: [number, number, number];
  angularVelocity: [number, number, number];
  colorHex: string;
  age: number;
  maxAge: number;
}

export type ThemeId =
  | 'prism'
  | 'sunset'
  | 'cyberpunk'
  | 'emerald'
  | 'obsidian'
  | 'aurora'
  | 'candy';

export type BlockMaterialStyle =
  | 'crystal'
  | 'metallic'
  | 'matte'
  | 'neon'
  | 'glossy';

export interface ThemeConfig {
  id: ThemeId;
  name: string;
  description: string;
  unlockFloor: number;
  skyTop: string;
  skyBottom: string;
  fogColor: string;
  pedestalColor: string;
  colorPalette: string[]; // Gradient anchor points
  accentColor: string;
}

export interface PlayerStats {
  highScore: number;
  gamesPlayed: number;
  totalBlocksStacked: number;
  totalPerfectHits: number;
  highestCombo: number;
  unlockedThemes: ThemeId[];
  unlockedStyles: BlockMaterialStyle[];
  activeTheme: ThemeId;
  activeStyle: BlockMaterialStyle;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  playerName: string;
}

export interface LeaderboardItem {
  id: string;
  rank: number;
  name: string;
  score: number;
  country: string;
  avatar: string;
  badge: string;
  date: string;
  isPlayer?: boolean;
}

export interface ChallengeItem {
  id: string;
  title: string;
  description: string;
  target: number;
  progress: number;
  completed: boolean;
  rewardType: 'theme' | 'style' | 'badge';
  rewardValue: string;
}
