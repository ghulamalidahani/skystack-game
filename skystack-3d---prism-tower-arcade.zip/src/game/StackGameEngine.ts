/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Axis, BlockData, BlockMaterialStyle, FallingDebrisData, ThemeId } from './types';
import { THEMES, getBlockColor, createBlockMaterial } from './themes';
import { sound } from './sound';
import { getSpeedMultiplier, getPerfectTolerance, checkLevelUp, LevelInfo } from './difficulty';

// Reusable math objects to guarantee zero GC during continuous animation loop
const _vec3 = new THREE.Vector3();
const _color = new THREE.Color();

export interface PlaceResult {
  success: boolean;
  isPerfect: boolean;
  isGameOver: boolean;
  score: number;
  combo: number;
  expanded: boolean;
  levelUp?: LevelInfo;
}

export class StackGameEngine {
  private container: HTMLElement;
  private canvas: HTMLCanvasElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.OrthographicCamera;
  private isSoftwareGl: boolean = false;
  private frameId: number = 0;
  private clock: THREE.Clock = new THREE.Clock();

  // Environment and lighting
  private ambientLight!: THREE.HemisphereLight;
  private dirLight!: THREE.DirectionalLight;
  private fog!: THREE.Fog;

  // Game Settings & Constants
  private readonly BLOCK_HEIGHT = 0.65;
  private readonly INITIAL_WIDTH = 3.2;
  private readonly INITIAL_DEPTH = 3.2;
  private readonly MOVE_AMPLITUDE = 4.4;
  private readonly PERFECT_TOLERANCE = 0.085;
  private readonly MAX_COMBO_EXPAND = 5;

  // Active game configuration
  private currentTheme: ThemeId = 'prism';
  private currentStyle: BlockMaterialStyle = 'glossy';

  // State
  private isPlaying: boolean = false;
  private isTitleDemo: boolean = true;
  private score: number = 0;
  private combo: number = 0;
  private currentAxis: Axis = 'x';
  private currentSpeed: number = 3.2;
  private moveDirection: number = 1;
  private moveOffset: number = 0;

  // Camera tracking
  private cameraTargetY: number = 0;
  private cameraCurrentY: number = 0;
  private screenShake: number = 0;

  // 3D Objects
  private pedestalGroup: THREE.Group = new THREE.Group();
  private towerGroup: THREE.Group = new THREE.Group();
  private debrisGroup: THREE.Group = new THREE.Group();
  private particleGroup: THREE.Group = new THREE.Group();
  private backgroundObjectsGroup: THREE.Group = new THREE.Group();

  // Visual Alignment Guide
  private alignmentGuideGroup: THREE.Group = new THREE.Group();
  private targetFootprintMesh!: THREE.Mesh;
  private verticalLaserMesh!: THREE.Mesh;

  // Tower Stack Data
  private placedBlocks: Array<{
    mesh: THREE.Mesh;
    data: BlockData;
  }> = [];

  // Active moving block
  private activeBlockMesh: THREE.Mesh | null = null;
  private activeBlockSize: [number, number, number] = [3.2, 0.65, 3.2];
  private currentTopPos: [number, number, number] = [0, 0, 0];

  // Falling debris list
  private fallingDebris: Array<{
    mesh: THREE.Mesh;
    data: FallingDebrisData;
  }> = [];

  // Sparkle / hitstop
  private hitstopUntil: number = 0;

  // Callbacks
  private onScoreUpdate?: (score: number, combo: number) => void;
  private onGameOver?: (score: number, maxCombo: number, perfectCount: number) => void;
  private perfectCount: number = 0;
  private maxCombo: number = 0;

  constructor(container: HTMLElement) {
    this.container = container;

    // 1. Detect Software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Initialize Three.js WebGLRenderer
    this.renderer = new THREE.WebGLRenderer({
      powerPreference: 'high-performance',
      antialias: !this.isSoftwareGl,
      preserveDrawingBuffer: true, // Needed for social share card screenshots
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.canvas = this.renderer.domElement;
    this.canvas.className = 'w-full h-full block select-none pointer-events-none';
    this.container.appendChild(this.canvas);

    // 3. Scene Setup
    this.scene = new THREE.Scene();
    const theme = THEMES[this.currentTheme];
    this.scene.background = new THREE.Color(theme.skyTop);
    this.fog = new THREE.Fog(theme.fogColor, 18, 52);
    this.scene.fog = this.fog;

    // 4. Procedural RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 5. Isometric Orthographic Camera
    const aspect = container.clientWidth / (container.clientHeight || 1);
    const frustumSize = 13;
    this.camera = new THREE.OrthographicCamera(
      (-frustumSize * aspect) / 2,
      (frustumSize * aspect) / 2,
      frustumSize / 2,
      -frustumSize / 2,
      -20,
      100
    );
    this.updateCameraIsometricPosition();

    // 6. Studio Lighting Rig
    this.setupLighting();

    // 7. Add Scene Groups
    this.scene.add(this.backgroundObjectsGroup);
    this.scene.add(this.pedestalGroup);
    this.scene.add(this.towerGroup);
    this.scene.add(this.alignmentGuideGroup);
    this.scene.add(this.debrisGroup);
    this.scene.add(this.particleGroup);

    // 8. Build Base Pedestal, Background Decor, and Alignment Guide
    this.buildPedestal();
    this.buildBackgroundDecor();
    this.buildAlignmentGuide();

    // 9. Resize Listener
    window.addEventListener('resize', this.handleResize);

    // 10. Start Animation Loop
    this.startLoop();
  }

  private setupLighting() {
    this.ambientLight = new THREE.HemisphereLight('#f8fafc', '#1e293b', 0.85);
    this.scene.add(this.ambientLight);

    this.dirLight = new THREE.DirectionalLight('#ffffff', 1.4);
    this.dirLight.position.set(12, 22, 10);
    if (!this.isSoftwareGl) {
      this.dirLight.castShadow = true;
      this.dirLight.shadow.mapSize.width = 1024;
      this.dirLight.shadow.mapSize.height = 1024;
      this.dirLight.shadow.camera.near = 0.5;
      this.dirLight.shadow.camera.far = 60;
      const d = 10;
      this.dirLight.shadow.camera.left = -d;
      this.dirLight.shadow.camera.right = d;
      this.dirLight.shadow.camera.top = d;
      this.dirLight.shadow.camera.bottom = -d;
      this.dirLight.shadow.bias = -0.0005;
      this.dirLight.shadow.normalBias = 0.02;
    }
    this.scene.add(this.dirLight);
  }

  /**
   * Sets up 3-part procedural grounded pedestal
   */
  private buildPedestal() {
    while (this.pedestalGroup.children.length > 0) {
      const child = this.pedestalGroup.children[0] as THREE.Mesh;
      if (child.geometry) child.geometry.dispose();
      this.pedestalGroup.remove(child);
    }

    const theme = THEMES[this.currentTheme];

    // Main base pedestal
    const baseGeo = new THREE.BoxGeometry(4.2, 1.2, 4.2);
    const baseMat = new THREE.MeshStandardMaterial({
      color: theme.pedestalColor,
      roughness: 0.4,
      metalness: 0.2,
    });
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.set(0, -0.6, 0);
    baseMesh.receiveShadow = !this.isSoftwareGl;
    this.pedestalGroup.add(baseMesh);

    // Accent trim plate
    const trimGeo = new THREE.BoxGeometry(4.4, 0.15, 4.4);
    const trimMat = new THREE.MeshStandardMaterial({
      color: theme.accentColor,
      roughness: 0.2,
      metalness: 0.8,
    });
    const trimMesh = new THREE.Mesh(trimGeo, trimMat);
    trimMesh.position.set(0, -1.25, 0);
    this.pedestalGroup.add(trimMesh);

    // Grounded contact shadow circle plane
    const shadowGeo = new THREE.PlaneGeometry(7.0, 7.0);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.set(0, -1.33, 0);
    this.pedestalGroup.add(shadowMesh);
  }

  /**
   * Ambient floating geometric stars / prisms in background for depth
   */
  private buildBackgroundDecor() {
    while (this.backgroundObjectsGroup.children.length > 0) {
      const child = this.backgroundObjectsGroup.children[0] as THREE.Mesh;
      if (child.geometry) child.geometry.dispose();
      this.backgroundObjectsGroup.remove(child);
    }

    const diamondGeo = new THREE.OctahedronGeometry(0.35);
    const diamondMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.2,
      metalness: 0.6,
      transparent: true,
      opacity: 0.35,
    });

    for (let i = 0; i < 35; i++) {
      const mesh = new THREE.Mesh(diamondGeo, diamondMat);
      const radius = 9 + Math.random() * 15;
      const angle = Math.random() * Math.PI * 2;
      mesh.position.set(
        Math.cos(angle) * radius,
        -5 + Math.random() * 50,
        Math.sin(angle) * radius
      );
      mesh.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3);
      mesh.scale.setScalar(0.5 + Math.random() * 0.8);
      this.backgroundObjectsGroup.add(mesh);
    }
  }

  private buildAlignmentGuide() {
    // Target footprint plane sitting flush on top of static block
    const footprintGeo = new THREE.PlaneGeometry(1, 1);
    const footprintMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.2,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    this.targetFootprintMesh = new THREE.Mesh(footprintGeo, footprintMat);
    this.targetFootprintMesh.rotation.x = -Math.PI / 2;
    this.alignmentGuideGroup.add(this.targetFootprintMesh);

    // Vertical laser beam plane connecting target top to moving block bottom
    const laserGeo = new THREE.PlaneGeometry(1, 1);
    const laserMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.12,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    this.verticalLaserMesh = new THREE.Mesh(laserGeo, laserMat);
    this.alignmentGuideGroup.add(this.verticalLaserMesh);

    this.alignmentGuideGroup.visible = false;
  }

  private updateCameraIsometricPosition() {
    const d = 15;
    // Standard 45-degree azimuth isometric angle
    this.camera.position.set(d, d * 1.25 + this.cameraCurrentY, d);
    const lookAtY = this.cameraCurrentY + 1.2;
    this.camera.lookAt(0, lookAtY, 0);

    // Apply screen shake
    if (this.screenShake > 0.001) {
      const sx = (Math.random() - 0.5) * this.screenShake;
      const sy = (Math.random() - 0.5) * this.screenShake;
      this.camera.position.x += sx;
      this.camera.position.y += sy;
    }
  }

  public setCallbacks(
    onScoreUpdate?: (score: number, combo: number) => void,
    onGameOver?: (score: number, maxCombo: number, perfectCount: number) => void
  ) {
    this.onScoreUpdate = onScoreUpdate;
    this.onGameOver = onGameOver;
  }

  public setTheme(themeId: ThemeId) {
    this.currentTheme = themeId;
    const theme = THEMES[themeId] || THEMES.prism;
    this.scene.background = new THREE.Color(theme.skyTop);
    this.fog.color.set(theme.fogColor);
    this.buildPedestal();

    // Update colors of placed blocks
    this.placedBlocks.forEach((b, idx) => {
      const col = getBlockColor(this.currentTheme, idx);
      b.data.colorHex = '#' + col.getHexString();
      const mat = createBlockMaterial(this.currentStyle, col, this.isSoftwareGl);
      b.mesh.material = mat;
    });

    if (this.activeBlockMesh) {
      const activeCol = getBlockColor(this.currentTheme, this.score + 1);
      this.activeBlockMesh.material = createBlockMaterial(this.currentStyle, activeCol, this.isSoftwareGl);
    }
  }

  public setStyle(style: BlockMaterialStyle) {
    this.currentStyle = style;
    this.placedBlocks.forEach((b) => {
      const col = new THREE.Color(b.data.colorHex);
      b.mesh.material = createBlockMaterial(this.currentStyle, col, this.isSoftwareGl);
    });
    if (this.activeBlockMesh) {
      const col = getBlockColor(this.currentTheme, this.score + 1);
      this.activeBlockMesh.material = createBlockMaterial(this.currentStyle, col, this.isSoftwareGl);
    }
  }

  /**
   * Resets and starts an interactive game session
   */
  public startNewGame() {
    this.clearTower();
    this.isPlaying = true;
    this.isTitleDemo = false;
    this.score = 0;
    this.combo = 0;
    this.perfectCount = 0;
    this.maxCombo = 0;
    this.cameraTargetY = 0;
    this.cameraCurrentY = 0;
    this.screenShake = 0;
    this.currentSpeed = 3.2;

    this.activeBlockSize = [this.INITIAL_WIDTH, this.BLOCK_HEIGHT, this.INITIAL_DEPTH];
    this.currentTopPos = [0, 0, 0];

    // Place Base Starting Block on pedestal
    const baseColor = getBlockColor(this.currentTheme, 0);
    this.addStaticBlock(
      [0, 0, 0],
      [this.INITIAL_WIDTH, this.BLOCK_HEIGHT, this.INITIAL_DEPTH],
      baseColor,
      0
    );

    // Spawn first moving block
    this.spawnNextMovingBlock();

    if (this.onScoreUpdate) {
      this.onScoreUpdate(this.score, this.combo);
    }
  }

  /**
   * Generates Title Screen live demonstration tower
   */
  public startTitleDemo() {
    this.clearTower();
    this.isPlaying = false;
    this.isTitleDemo = true;
    this.cameraTargetY = 4.0;

    // Generate a beautiful demo spiral stack
    const count = 10;
    let currW = 3.2;
    let currD = 3.2;
    let currX = 0;
    let currZ = 0;

    for (let i = 0; i < count; i++) {
      const col = getBlockColor(this.currentTheme, i);
      const y = i * this.BLOCK_HEIGHT;
      if (i > 0) {
        if (i % 2 === 1) {
          currX += (Math.sin(i) * 0.15);
        } else {
          currZ += (Math.cos(i) * 0.15);
        }
      }
      this.addStaticBlock([currX, y, currZ], [currW, this.BLOCK_HEIGHT, currD], col, i);
    }
  }

  private clearTower() {
    this.placedBlocks.forEach((b) => {
      if (b.mesh.geometry) b.mesh.geometry.dispose();
      this.towerGroup.remove(b.mesh);
    });
    this.placedBlocks = [];

    this.fallingDebris.forEach((d) => {
      if (d.mesh.geometry) d.mesh.geometry.dispose();
      this.debrisGroup.remove(d.mesh);
    });
    this.fallingDebris = [];

    if (this.activeBlockMesh) {
      if (this.activeBlockMesh.geometry) this.activeBlockMesh.geometry.dispose();
      this.towerGroup.remove(this.activeBlockMesh);
      this.activeBlockMesh = null;
    }
  }

  private addStaticBlock(
    pos: [number, number, number],
    size: [number, number, number],
    color: THREE.Color,
    floorIndex: number,
    isPerfect?: boolean
  ) {
    const geo = new THREE.BoxGeometry(size[0], size[1], size[2]);
    const mat = createBlockMaterial(this.currentStyle, color, this.isSoftwareGl);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(pos[0], pos[1], pos[2]);
    mesh.castShadow = !this.isSoftwareGl;
    mesh.receiveShadow = !this.isSoftwareGl;

    this.towerGroup.add(mesh);
    this.placedBlocks.push({
      mesh,
      data: {
        id: floorIndex,
        position: pos,
        size,
        colorHex: '#' + color.getHexString(),
        isPerfect,
      },
    });

    this.currentTopPos = pos;
  }

  private spawnNextMovingBlock() {
    if (this.activeBlockMesh) {
      this.towerGroup.remove(this.activeBlockMesh);
      this.activeBlockMesh = null;
    }

    const nextFloor = this.score + 1;
    // Levels 1-2 (Floors 1-15): Standard alternating X and Z
    // Levels 3+ (Floors 16+): Slicing axes change more dynamically
    if (nextFloor > 16 && nextFloor % 5 === 0) {
      // Repeat same axis occasionally in hard mode to test timing agility
      this.currentAxis = this.currentAxis;
    } else {
      this.currentAxis = nextFloor % 2 === 1 ? 'x' : 'z';
    }

    // Variable speed multiplier: Floor 1 is 0.5x, Floor 10 is 1.0x, Floor 20 is 1.5x, Floor 30+ scales up to 2.25x
    const baseSpeed = 3.2;
    this.currentSpeed = baseSpeed * getSpeedMultiplier(nextFloor);
    this.moveDirection = Math.random() > 0.5 ? 1 : -1;
    this.moveOffset = -this.MOVE_AMPLITUDE * this.moveDirection;

    const y = nextFloor * this.BLOCK_HEIGHT;
    const color = getBlockColor(this.currentTheme, nextFloor);
    const geo = new THREE.BoxGeometry(this.activeBlockSize[0], this.activeBlockSize[1], this.activeBlockSize[2]);
    const mat = createBlockMaterial(this.currentStyle, color, this.isSoftwareGl);

    this.activeBlockMesh = new THREE.Mesh(geo, mat);
    this.activeBlockMesh.castShadow = !this.isSoftwareGl;
    this.activeBlockMesh.receiveShadow = !this.isSoftwareGl;

    if (this.currentAxis === 'x') {
      this.activeBlockMesh.position.set(this.moveOffset, y, this.currentTopPos[2]);
    } else {
      this.activeBlockMesh.position.set(this.currentTopPos[0], y, this.moveOffset);
    }

    this.towerGroup.add(this.activeBlockMesh);
  }

  /**
   * Primary action triggered on tap/spacebar
   */
  public placeBlock(): PlaceResult {
    if (!this.isPlaying || !this.activeBlockMesh) {
      return { success: false, isPerfect: false, isGameOver: false, score: this.score, combo: this.combo, expanded: false };
    }

    const currentX = this.activeBlockMesh.position.x;
    const currentZ = this.activeBlockMesh.position.z;
    const y = this.activeBlockMesh.position.y;

    const prevX = this.currentTopPos[0];
    const prevZ = this.currentTopPos[2];

    const currentW = this.activeBlockSize[0];
    const currentD = this.activeBlockSize[2];

    let diff = 0;
    let totalDimOnAxis = 0;

    if (this.currentAxis === 'x') {
      diff = currentX - prevX;
      totalDimOnAxis = currentW;
    } else {
      diff = currentZ - prevZ;
      totalDimOnAxis = currentD;
    }

    let dist = Math.abs(diff);

    // 1. COMPLETE MISS
    if (dist >= totalDimOnAxis) {
      this.triggerGameOver(this.activeBlockMesh);
      return { success: false, isPerfect: false, isGameOver: true, score: this.score, combo: this.combo, expanded: false };
    }

    const floorIndex = this.score + 1;
    const blockColor = getBlockColor(this.currentTheme, floorIndex);
    const tolerance = getPerfectTolerance(floorIndex);
    const levelUp = checkLevelUp(this.score, floorIndex) || undefined;

    // Forgiving onboarding: For the first 5 blocks, if player misses a perfect shot,
    // do not immediately reduce the block size drastically.
    if (floorIndex <= 5 && dist > tolerance) {
      const maxAllowedCut = totalDimOnAxis * 0.18; // At most 18% cut in warmup floors
      if (dist > maxAllowedCut) {
        dist = maxAllowedCut;
        diff = diff > 0 ? maxAllowedCut : -maxAllowedCut;
      }
    }

    // 2. PERFECT PLACEMENT
    if (dist <= tolerance) {
      this.combo++;
      this.perfectCount++;
      if (this.combo > this.maxCombo) {
        this.maxCombo = this.combo;
      }

      let expanded = false;
      // Bonus: If player gets high combo (5x Perfect), expand the tower block back!
      if (this.combo >= this.MAX_COMBO_EXPAND) {
        const bonus = 0.32;
        this.activeBlockSize[0] = Math.min(this.INITIAL_WIDTH, this.activeBlockSize[0] + bonus);
        this.activeBlockSize[2] = Math.min(this.INITIAL_DEPTH, this.activeBlockSize[2] + bonus);
        sound.playTowerExpand();
        expanded = true;
      } else {
        sound.playPerfect(this.combo);
      }

      // Snap exactly to previous coordinate
      const snappedPos: [number, number, number] = [prevX, y, prevZ];
      this.addStaticBlock(snappedPos, [...this.activeBlockSize], blockColor, floorIndex, true);

      // Visual punch & sparkles
      this.hitstopUntil = performance.now() + 35;
      this.screenShake = 0.08;
      this.spawnPerfectSparkles(snappedPos, this.activeBlockSize, blockColor);

      // Score + 1 (+ combo bonus in stats)
      this.score++;
      this.cameraTargetY = this.score * this.BLOCK_HEIGHT;

      if (this.onScoreUpdate) {
        this.onScoreUpdate(this.score, this.combo);
      }

      this.spawnNextMovingBlock();
      return { success: true, isPerfect: true, isGameOver: false, score: this.score, combo: this.combo, expanded, levelUp };
    }

    // 3. SLICE & OVERHANG
    this.combo = 0; // combo reset
    sound.playSlice();
    sound.playPlace(0, floorIndex);

    const overlap = totalDimOnAxis - dist;
    const overhang = dist;

    let newW = currentW;
    let newD = currentD;
    let newX = currentX;
    let newZ = currentZ;

    let cutW = currentW;
    let cutD = currentD;
    let cutX = currentX;
    let cutZ = currentZ;

    if (this.currentAxis === 'x') {
      newW = overlap;
      cutW = overhang;
      newX = prevX + diff / 2;
      cutX = diff > 0 ? newX + newW / 2 + cutW / 2 : newX - newW / 2 - cutW / 2;
    } else {
      newD = overlap;
      cutD = overhang;
      newZ = prevZ + diff / 2;
      cutZ = diff > 0 ? newZ + newD / 2 + cutD / 2 : newZ - newD / 2 - cutD / 2;
    }

    // Update active size for subsequent floors
    this.activeBlockSize = [newW, this.BLOCK_HEIGHT, newD];

    // Add retained static block
    this.addStaticBlock([newX, y, newZ], [newW, this.BLOCK_HEIGHT, newD], blockColor, floorIndex, false);

    // Spawn falling cut-off debris with physics
    this.spawnFallingDebris(
      [cutX, y, cutZ],
      [cutW, this.BLOCK_HEIGHT, cutD],
      blockColor,
      this.currentAxis,
      diff > 0 ? 1 : -1
    );

    // Camera punch and shake
    this.screenShake = 0.12;

    this.score++;
    this.cameraTargetY = this.score * this.BLOCK_HEIGHT;

    if (this.onScoreUpdate) {
      this.onScoreUpdate(this.score, this.combo);
    }

    this.spawnNextMovingBlock();
    return { success: true, isPerfect: false, isGameOver: false, score: this.score, combo: 0, expanded: false, levelUp };
  }

  private spawnFallingDebris(
    pos: [number, number, number],
    size: [number, number, number],
    color: THREE.Color,
    axis: Axis,
    directionSign: number
  ) {
    const geo = new THREE.BoxGeometry(size[0], size[1], size[2]);
    const mat = createBlockMaterial(this.currentStyle, color, this.isSoftwareGl);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(pos[0], pos[1], pos[2]);
    mesh.castShadow = !this.isSoftwareGl;
    this.debrisGroup.add(mesh);

    const vx = axis === 'x' ? directionSign * (1.2 + Math.random() * 1.5) : (Math.random() - 0.5) * 0.8;
    const vz = axis === 'z' ? directionSign * (1.2 + Math.random() * 1.5) : (Math.random() - 0.5) * 0.8;

    this.fallingDebris.push({
      mesh,
      data: {
        id: Math.random(),
        position: pos,
        size,
        velocity: [vx, -0.5, vz],
        angularVelocity: [
          (Math.random() - 0.5) * 6,
          (Math.random() - 0.5) * 4,
          (Math.random() - 0.5) * 6,
        ],
        colorHex: '#' + color.getHexString(),
        age: 0,
        maxAge: 3.5,
      },
    });
  }

  private triggerGameOver(missedMesh: THREE.Mesh) {
    this.isPlaying = false;
    sound.playGameOver();
    this.screenShake = 0.35;

    // Convert missed mesh into falling piece
    const pos: [number, number, number] = [
      missedMesh.position.x,
      missedMesh.position.y,
      missedMesh.position.z,
    ];
    const col = getBlockColor(this.currentTheme, this.score + 1);

    this.towerGroup.remove(missedMesh);
    this.activeBlockMesh = null;

    this.spawnFallingDebris(
      pos,
      [this.activeBlockSize[0], this.BLOCK_HEIGHT, this.activeBlockSize[2]],
      col,
      this.currentAxis,
      this.moveDirection
    );

    if (this.onGameOver) {
      this.onGameOver(this.score, this.maxCombo, this.perfectCount);
    }
  }

  private spawnPerfectSparkles(
    center: [number, number, number],
    size: [number, number, number],
    color: THREE.Color
  ) {
    const count = 16;
    const particleGeo = new THREE.BoxGeometry(0.12, 0.12, 0.12);
    const particleMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.9,
    });

    const wHalf = size[0] / 2;
    const dHalf = size[2] / 2;

    for (let i = 0; i < count; i++) {
      const mesh = new THREE.Mesh(particleGeo, particleMat);
      // Position around perimeter
      const u = Math.random();
      let px = 0;
      let pz = 0;
      if (i % 4 === 0) {
        px = -wHalf + u * size[0];
        pz = -dHalf;
      } else if (i % 4 === 1) {
        px = wHalf;
        pz = -dHalf + u * size[2];
      } else if (i % 4 === 2) {
        px = -wHalf + u * size[0];
        pz = dHalf;
      } else {
        px = -wHalf;
        pz = -dHalf + u * size[2];
      }

      mesh.position.set(center[0] + px, center[1] + size[1] / 2 + 0.05, center[2] + pz);
      this.particleGroup.add(mesh);

      // Animate sparkle burst
      const vy = 1.8 + Math.random() * 2.5;
      const vx = (px / (wHalf || 1)) * 1.5;
      const vz = (pz / (dHalf || 1)) * 1.5;

      const birth = performance.now();
      const lifeTime = 450;

      const anim = () => {
        const elapsed = performance.now() - birth;
        const progress = elapsed / lifeTime;
        if (progress >= 1) {
          if (mesh.geometry) mesh.geometry.dispose();
          this.particleGroup.remove(mesh);
          return;
        }
        mesh.position.y += vy * 0.016;
        mesh.position.x += vx * 0.016;
        mesh.position.z += vz * 0.016;
        mesh.scale.setScalar(Math.max(0.01, 1 - progress));
        mesh.rotation.x += 0.1;
        mesh.rotation.y += 0.1;
        requestAnimationFrame(anim);
      };
      requestAnimationFrame(anim);
    }
  }

  private handleResize = () => {
    if (!this.container) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight || 1;
    const aspect = width / height;
    const frustumSize = 13;

    this.camera.left = (-frustumSize * aspect) / 2;
    this.camera.right = (frustumSize * aspect) / 2;
    this.camera.top = frustumSize / 2;
    this.camera.bottom = -frustumSize / 2;
    this.camera.updateProjectionMatrix();

    this.renderer.setSize(width, height);
  };

  private startLoop() {
    this.clock.start();
    const tick = () => {
      const rawDt = this.clock.getDelta();
      const dt = Math.min(rawDt, 0.05);

      this.update(dt);
      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.afterDraw(tick);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private update(dt: number) {
    // Check hitstop pause
    if (performance.now() < this.hitstopUntil) {
      return;
    }

    // 1. Update Camera Position via exponential damping
    this.cameraCurrentY = THREE.MathUtils.damp(this.cameraCurrentY, this.cameraTargetY, 4.5, dt);

    // Decay screen shake
    if (this.screenShake > 0) {
      this.screenShake = Math.max(0, this.screenShake - dt * 1.5);
    }
    this.updateCameraIsometricPosition();

    // 2. Animate background floating diamonds gently
    this.backgroundObjectsGroup.children.forEach((child, i) => {
      child.rotation.x += dt * 0.25;
      child.rotation.y += dt * 0.35;
      child.position.y += Math.sin(this.clock.elapsedTime + i) * dt * 0.2;
    });

    // 3. Title demo camera rotation
    if (this.isTitleDemo) {
      this.alignmentGuideGroup.visible = false;
      const angle = this.clock.elapsedTime * 0.45;
      const radius = 17;
      this.camera.position.x = Math.cos(angle) * radius;
      this.camera.position.z = Math.sin(angle) * radius;
      this.camera.position.y = 12 + this.cameraCurrentY;
      this.camera.lookAt(0, this.cameraCurrentY + 1.2, 0);
      return;
    }

    // 4. Update Moving Block and Visual Alignment Guide in game
    if (this.isPlaying && this.activeBlockMesh) {
      this.moveOffset += this.moveDirection * this.currentSpeed * dt;

      if (this.moveOffset > this.MOVE_AMPLITUDE) {
        this.moveOffset = this.MOVE_AMPLITUDE;
        this.moveDirection = -1;
      } else if (this.moveOffset < -this.MOVE_AMPLITUDE) {
        this.moveOffset = -this.MOVE_AMPLITUDE;
        this.moveDirection = 1;
      }

      if (this.currentAxis === 'x') {
        this.activeBlockMesh.position.x = this.currentTopPos[0] + this.moveOffset;
      } else {
        this.activeBlockMesh.position.z = this.currentTopPos[2] + this.moveOffset;
      }

      // Update Visual Alignment Guide
      this.alignmentGuideGroup.visible = true;

      const yTop = this.currentTopPos[1] + this.BLOCK_HEIGHT / 2;
      const yActive = this.activeBlockMesh.position.y - this.BLOCK_HEIGHT / 2;
      const beamHeight = Math.max(0.08, yActive - yTop);

      // Footprint position & scale on top of static block
      this.targetFootprintMesh.position.set(
        this.currentTopPos[0],
        yTop + 0.005,
        this.currentTopPos[2]
      );
      this.targetFootprintMesh.scale.set(this.activeBlockSize[0], this.activeBlockSize[2], 1);

      // Vertical laser beam position & scale
      this.verticalLaserMesh.position.set(
        this.currentTopPos[0],
        yTop + beamHeight / 2,
        this.currentTopPos[2]
      );

      if (this.currentAxis === 'x') {
        this.verticalLaserMesh.rotation.y = 0;
        this.verticalLaserMesh.scale.set(this.activeBlockSize[0], beamHeight, 1);
      } else {
        this.verticalLaserMesh.rotation.y = Math.PI / 2;
        this.verticalLaserMesh.scale.set(this.activeBlockSize[2], beamHeight, 1);
      }

      // Calculate alignment proximity and lock-on glow
      const diff =
        this.currentAxis === 'x'
          ? this.activeBlockMesh.position.x - this.currentTopPos[0]
          : this.activeBlockMesh.position.z - this.currentTopPos[2];
      const dist = Math.abs(diff);
      const tolerance = getPerfectTolerance(this.score + 1);

      const fpMat = this.targetFootprintMesh.material as THREE.MeshBasicMaterial;
      const laserMat = this.verticalLaserMesh.material as THREE.MeshBasicMaterial;

      if (dist <= tolerance) {
        // Perfect lock-on! Bright gold glow
        fpMat.color.setHex(0xfacc15);
        fpMat.opacity = 0.65;
        laserMat.color.setHex(0xfacc15);
        laserMat.opacity = 0.35;
      } else {
        // Soft cyan proximity tracking
        const proximity = Math.max(0, 1 - dist / (this.activeBlockSize[0] || 1));
        fpMat.color.setHex(0x38bdf8);
        fpMat.opacity = 0.15 + proximity * 0.25;
        laserMat.color.setHex(0x38bdf8);
        laserMat.opacity = 0.06 + proximity * 0.15;
      }
    } else {
      this.alignmentGuideGroup.visible = false;
    }

    // 5. Update Falling Debris Physics
    const gravity = -26.0;
    for (let i = this.fallingDebris.length - 1; i >= 0; i--) {
      const debris = this.fallingDebris[i];
      debris.data.age += dt;

      // Velocity & Gravity
      debris.data.velocity[1] += gravity * dt;
      debris.mesh.position.x += debris.data.velocity[0] * dt;
      debris.mesh.position.y += debris.data.velocity[1] * dt;
      debris.mesh.position.z += debris.data.velocity[2] * dt;

      // Angular spin
      debris.mesh.rotation.x += debris.data.angularVelocity[0] * dt;
      debris.mesh.rotation.y += debris.data.angularVelocity[1] * dt;
      debris.mesh.rotation.z += debris.data.angularVelocity[2] * dt;

      // Fade or remove
      if (debris.data.age >= debris.data.maxAge || debris.mesh.position.y < -15) {
        if (debris.mesh.geometry) debris.mesh.geometry.dispose();
        this.debrisGroup.remove(debris.mesh);
        this.fallingDebris.splice(i, 1);
      }
    }
  }

  /**
   * Captures canvas as base64 PNG data URL for social card sharing
   */
  public captureScreenshot(): string {
    this.renderer.render(this.scene, this.camera);
    return this.canvas.toDataURL('image/png');
  }

  public dispose() {
    window.removeEventListener('resize', this.handleResize);
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    this.clearTower();
    this.backgroundObjectsGroup.clear();
    this.pedestalGroup.clear();
    this.particleGroup.clear();
    this.alignmentGuideGroup.clear();

    this.renderer.dispose();
    if (this.canvas.parentElement) {
      this.canvas.parentElement.removeChild(this.canvas);
    }
  }
}
