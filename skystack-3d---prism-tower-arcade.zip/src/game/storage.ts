/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PlayerStats, LeaderboardItem, ChallengeItem, ThemeId, BlockMaterialStyle } from './types';

const STATS_KEY = 'skystack_player_stats_v1';
const HISTORY_KEY = 'skystack_history_v1';

const DEFAULT_STATS: PlayerStats = {
  highScore: 0,
  gamesPlayed: 0,
  totalBlocksStacked: 0,
  totalPerfectHits: 0,
  highestCombo: 0,
  unlockedThemes: ['prism'],
  unlockedStyles: ['glossy'],
  activeTheme: 'prism',
  activeStyle: 'glossy',
  soundEnabled: true,
  hapticsEnabled: true,
  playerName: 'Stacker ' + Math.floor(1000 + Math.random() * 9000),
};

const BASE_LEADERBOARD: Omit<LeaderboardItem, 'rank' | 'isPlayer'>[] = [
  { id: '1', name: 'NovaVortex', score: 142, country: '🇰🇷', avatar: '⚡', badge: 'Grandmaster', date: 'Today' },
  { id: '2', name: 'ZenithPulse', score: 128, country: '🇯🇵', avatar: '🌸', badge: 'Grandmaster', date: 'Today' },
  { id: '3', name: 'ApexStacker', score: 119, country: '🇺🇸', avatar: '🦅', badge: 'Grandmaster', date: 'Yesterday' },
  { id: '4', name: 'PrismKnight', score: 98, country: '🇩🇪', avatar: '🛡️', badge: 'Master', date: 'Yesterday' },
  { id: '5', name: 'AeroSky', score: 87, country: '🇬🇧', avatar: '🚀', badge: 'Master', date: '2d ago' },
  { id: '6', name: 'Valkyrie99', score: 76, country: '🇸🇪', avatar: '⚔️', badge: 'Diamond', date: '3d ago' },
  { id: '7', name: 'EchoFrost', score: 68, country: '🇨🇦', avatar: '❄️', badge: 'Diamond', date: '3d ago' },
  { id: '8', name: 'SolarisX', score: 61, country: '🇧🇷', avatar: '☀️', badge: 'Platinum', date: '4d ago' },
  { id: '9', name: 'Hyperion', score: 54, country: '🇫🇷', avatar: '🗼', badge: 'Platinum', date: '5d ago' },
  { id: '10', name: 'LunarEcho', score: 48, country: '🇦🇺', avatar: '🌙', badge: 'Gold', date: '6d ago' },
  { id: '11', name: 'NexusGamer', score: 42, country: '🇮🇳', avatar: '🎮', badge: 'Gold', date: '1w ago' },
  { id: '12', name: 'SkySurfer', score: 36, country: '🇪🇸', avatar: '🏄', badge: 'Silver', date: '1w ago' },
  { id: '13', name: 'PixelForge', score: 29, country: '🇮🇹', avatar: '🧱', badge: 'Silver', date: '2w ago' },
  { id: '14', name: 'RhythmPulse', score: 22, country: '🇲🇽', avatar: '🎵', badge: 'Bronze', date: '2w ago' },
  { id: '15', name: 'BlockNovice', score: 15, country: '🇳🇱', avatar: '🌱', badge: 'Bronze', date: '3w ago' },
];

export const INITIAL_CHALLENGES: ChallengeItem[] = [
  {
    id: 'c1',
    title: 'First Ascent',
    description: 'Reach Floor 10 in any game',
    target: 10,
    progress: 0,
    completed: false,
    rewardType: 'style',
    rewardValue: 'matte',
  },
  {
    id: 'c2',
    title: 'Sunset Climber',
    description: 'Reach Floor 15 to unlock Sunset Theme',
    target: 15,
    progress: 0,
    completed: false,
    rewardType: 'theme',
    rewardValue: 'sunset',
  },
  {
    id: 'c3',
    title: 'Chime Virtuoso',
    description: 'Achieve a 4x consecutive Perfect streak',
    target: 4,
    progress: 0,
    completed: false,
    rewardType: 'style',
    rewardValue: 'crystal',
  },
  {
    id: 'c4',
    title: 'Neon Skyline',
    description: 'Reach Floor 30 to unlock Cyberpunk Theme',
    target: 30,
    progress: 0,
    completed: false,
    rewardType: 'theme',
    rewardValue: 'cyberpunk',
  },
  {
    id: 'c5',
    title: 'Titan of Balance',
    description: 'Reach Floor 45 to unlock Emerald Grove Theme',
    target: 45,
    progress: 0,
    completed: false,
    rewardType: 'theme',
    rewardValue: 'emerald',
  },
  {
    id: 'c6',
    title: 'Gilded Architecture',
    description: 'Reach Floor 60 to unlock Obsidian & Gold Theme',
    target: 60,
    progress: 0,
    completed: false,
    rewardType: 'theme',
    rewardValue: 'obsidian',
  },
  {
    id: 'c7',
    title: 'Chrome Master',
    description: 'Stack a total of 150 blocks across all games',
    target: 150,
    progress: 0,
    completed: false,
    rewardType: 'style',
    rewardValue: 'metallic',
  },
  {
    id: 'c8',
    title: 'Cosmic Core',
    description: 'Achieve a 7x Perfect combo or score 80',
    target: 80,
    progress: 0,
    completed: false,
    rewardType: 'style',
    rewardValue: 'neon',
  },
];

export function loadPlayerStats(): PlayerStats {
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_STATS, ...parsed };
    }
  } catch {
    // Ignore fallback
  }
  return DEFAULT_STATS;
}

export function savePlayerStats(stats: PlayerStats): void {
  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  } catch {
    // Ignore
  }
}

export interface GameRunRecord {
  id: string;
  score: number;
  maxCombo: number;
  perfectHits: number;
  date: string;
  theme: ThemeId;
}

export function loadRunHistory(): GameRunRecord[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // Ignore
  }
  return [];
}

export function saveRunHistory(run: GameRunRecord): void {
  try {
    const list = loadRunHistory();
    list.unshift(run);
    if (list.length > 25) list.pop();
    localStorage.setItem(HISTORY_KEY, JSON.stringify(list));
  } catch {
    // Ignore
  }
}

/**
 * Generates ranked global leaderboard including player's current high score
 */
export function getCombinedLeaderboard(playerScore: number, playerName: string): LeaderboardItem[] {
  const items = BASE_LEADERBOARD.map((item) => ({ ...item, isPlayer: false }));

  // Add player entry
  const playerTier =
    playerScore >= 110
      ? 'Grandmaster'
      : playerScore >= 80
      ? 'Master'
      : playerScore >= 60
      ? 'Diamond'
      : playerScore >= 45
      ? 'Platinum'
      : playerScore >= 30
      ? 'Gold'
      : playerScore >= 15
      ? 'Silver'
      : 'Bronze';

  items.push({
    id: 'player',
    name: playerName || 'You',
    score: playerScore,
    country: '⭐',
    avatar: '👑',
    badge: playerTier,
    date: 'Now',
    isPlayer: true,
  });

  // Sort descending by score
  items.sort((a, b) => b.score - a.score);

  return items.map((item, index) => ({
    ...item,
    rank: index + 1,
  }));
}

/**
 * Updates stats after a completed game run and checks unlocks
 */
export function processGameEndStats(
  currentStats: PlayerStats,
  score: number,
  perfectCount: number,
  maxCombo: number
): { updatedStats: PlayerStats; newlyUnlocked: string[] } {
  const newlyUnlocked: string[] = [];

  const newHighScore = Math.max(currentStats.highScore, score);
  const newHighestCombo = Math.max(currentStats.highestCombo, maxCombo);
  const newTotalStacked = currentStats.totalBlocksStacked + score;
  const newTotalPerfect = currentStats.totalPerfectHits + perfectCount;

  const unlockedThemes = [...currentStats.unlockedThemes];
  const unlockedStyles = [...currentStats.unlockedStyles];

  // Check Theme Unlocks
  const themeUnlocks: { id: ThemeId; name: string; condition: boolean }[] = [
    { id: 'sunset', name: 'Sunset Horizon', condition: newHighScore >= 15 },
    { id: 'cyberpunk', name: 'Cyberpunk 2099', condition: newHighScore >= 30 },
    { id: 'emerald', name: 'Emerald Grove', condition: newHighScore >= 45 },
    { id: 'obsidian', name: 'Obsidian & Gold', condition: newHighScore >= 60 },
    { id: 'aurora', name: 'Aurora Borealis', condition: newHighScore >= 80 },
    { id: 'candy', name: 'Candy Dream', condition: newHighScore >= 100 },
  ];

  themeUnlocks.forEach((t) => {
    if (t.condition && !unlockedThemes.includes(t.id)) {
      unlockedThemes.push(t.id);
      newlyUnlocked.push(`Theme: ${t.name}`);
    }
  });

  // Check Material Style Unlocks
  const styleUnlocks: { id: BlockMaterialStyle; name: string; condition: boolean }[] = [
    { id: 'matte', name: 'Matte Clay', condition: newHighScore >= 10 },
    { id: 'crystal', name: 'Prism Crystal Glass', condition: newHighestCombo >= 4 || newHighScore >= 20 },
    { id: 'metallic', name: 'Polished Chrome', condition: newTotalStacked >= 100 || newHighScore >= 40 },
    { id: 'neon', name: 'Neon Glow Core', condition: newHighestCombo >= 6 || newHighScore >= 70 },
  ];

  styleUnlocks.forEach((s) => {
    if (s.condition && !unlockedStyles.includes(s.id)) {
      unlockedStyles.push(s.id);
      newlyUnlocked.push(`Material: ${s.name}`);
    }
  });

  const updatedStats: PlayerStats = {
    ...currentStats,
    highScore: newHighScore,
    gamesPlayed: currentStats.gamesPlayed + 1,
    totalBlocksStacked: newTotalStacked,
    totalPerfectHits: newTotalPerfect,
    highestCombo: newHighestCombo,
    unlockedThemes,
    unlockedStyles,
  };

  savePlayerStats(updatedStats);

  // Save to history
  saveRunHistory({
    id: Date.now().toString(),
    score,
    maxCombo,
    perfectHits: perfectCount,
    date: new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
    theme: currentStats.activeTheme,
  });

  return { updatedStats, newlyUnlocked };
}
