/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { StackGameEngine } from './game/StackGameEngine';
import { GameState, ThemeId, BlockMaterialStyle, LeaderboardItem } from './game/types';
import { THEMES } from './game/themes';
import { sound } from './game/sound';
import {
  loadPlayerStats,
  savePlayerStats,
  getCombinedLeaderboard,
  processGameEndStats,
  loadRunHistory,
  GameRunRecord,
} from './game/storage';

import { TitleScreen } from './components/TitleScreen';
import { GameHUD, FloatingFeedback, LevelBannerData } from './components/GameHUD';
import { GameOverModal } from './components/GameOverModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { ThemeShopModal } from './components/ThemeShopModal';
import { ShareModal } from './components/ShareModal';
import { PauseModal } from './components/PauseModal';
import { TutorialModal } from './components/TutorialModal';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<StackGameEngine | null>(null);

  // Player persistent stats
  const [stats, setStats] = useState(loadPlayerStats);
  const [history, setHistory] = useState<GameRunRecord[]>(loadRunHistory);

  // Game UI state
  const [gameState, setGameState] = useState<GameState>('title');
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);

  // Modals state
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showThemes, setShowThemes] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);

  // Game over review info
  const [lastMaxCombo, setLastMaxCombo] = useState(0);
  const [lastPerfectCount, setLastPerfectCount] = useState(0);
  const [isNewHighScore, setIsNewHighScore] = useState(false);
  const [newlyUnlocked, setNewlyUnlocked] = useState<string[]>([]);
  const [screenshotUrl, setScreenshotUrl] = useState<string | null>(null);

  // In-Game floating combo & mastery feedback
  const [feedback, setFeedback] = useState<FloatingFeedback | null>(null);
  const feedbackTimeoutRef = useRef<number | null>(null);

  // Level progression announcement banner
  const [levelBanner, setLevelBanner] = useState<LevelBannerData | null>(null);
  const levelTimeoutRef = useRef<number | null>(null);

  // Active game state ref for 100% reliable global touch/click dispatch without stale closures
  const gameStateRef = useRef<GameState>(gameState);
  useEffect(() => {
    gameStateRef.current = gameState;
  }, [gameState]);

  const lastPlaceTimeRef = useRef(0);
  const gameOverTimeRef = useRef(0);

  useEffect(() => {
    return () => {
      if (feedbackTimeoutRef.current) {
        clearTimeout(feedbackTimeoutRef.current);
      }
      if (levelTimeoutRef.current) {
        clearTimeout(levelTimeoutRef.current);
      }
    };
  }, []);

  // Synchronize audio and haptics settings
  useEffect(() => {
    sound.setMuted(!stats.soundEnabled);
    sound.setHaptics(stats.hapticsEnabled);
  }, [stats.soundEnabled, stats.hapticsEnabled]);

  // Handle Score Updates from Engine
  const handleScoreUpdate = useCallback((newScore: number, newCombo: number) => {
    setScore(newScore);
    setCombo(newCombo);
  }, []);

  // Handle Game Over from Engine
  const handleGameOver = useCallback(
    (finalScore: number, maxCombo: number, perfectCount: number) => {
      setLastMaxCombo(maxCombo);
      setLastPerfectCount(perfectCount);
      setIsNewHighScore(finalScore > stats.highScore);

      // Process unlocks and update persistent storage
      const { updatedStats, newlyUnlocked: unlocked } = processGameEndStats(
        stats,
        finalScore,
        perfectCount,
        maxCombo
      );
      setStats(updatedStats);
      setNewlyUnlocked(unlocked);
      setHistory(loadRunHistory());

      // Capture screenshot after a brief tick so debris is visible
      setTimeout(() => {
        if (engineRef.current) {
          try {
            const shot = engineRef.current.captureScreenshot();
            setScreenshotUrl(shot);
          } catch {
            // Ignore capture error
          }
        }
      }, 100);

      gameOverTimeRef.current = Date.now();
      setGameState('gameover');
    },
    [stats]
  );

  // Mount 3D Three.js Engine once on startup
  useEffect(() => {
    if (!mountRef.current) return;

    const engine = new StackGameEngine(mountRef.current);
    engineRef.current = engine;

    engine.setTheme(stats.activeTheme);
    engine.setStyle(stats.activeStyle);
    engine.setCallbacks(handleScoreUpdate, handleGameOver);
    engine.startTitleDemo();

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []); // Run once on mount

  // Sync callbacks if handleGameOver dependencies change
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.setCallbacks(handleScoreUpdate, handleGameOver);
    }
  }, [handleScoreUpdate, handleGameOver]);

  // Start new game action
  const handleStartGame = useCallback(() => {
    if (!engineRef.current) return;
    setScore(0);
    setCombo(0);
    setNewlyUnlocked([]);
    setScreenshotUrl(null);
    setFeedback(null);
    if (feedbackTimeoutRef.current) {
      clearTimeout(feedbackTimeoutRef.current);
    }
    setLevelBanner({
      id: Date.now(),
      title: 'Level 1',
      subtitle: 'Warm Up',
    });
    if (levelTimeoutRef.current) {
      clearTimeout(levelTimeoutRef.current);
    }
    levelTimeoutRef.current = window.setTimeout(() => {
      setLevelBanner(null);
    }, 2200);
    setGameState('playing');
    engineRef.current.startNewGame();
  }, []);

  // Primary block placement action
  const handlePlaceAction = useCallback(() => {
    if (gameStateRef.current !== 'playing' || !engineRef.current) return;
    const now = Date.now();
    if (now - lastPlaceTimeRef.current < 60) return;
    lastPlaceTimeRef.current = now;

    const result = engineRef.current.placeBlock();

    // Visual feedback for level progression
    if (result.levelUp) {
      if (levelTimeoutRef.current) {
        clearTimeout(levelTimeoutRef.current);
      }
      setLevelBanner({
        id: Date.now(),
        title: result.levelUp.name,
        subtitle: result.levelUp.subtitle,
      });
      levelTimeoutRef.current = window.setTimeout(() => {
        setLevelBanner(null);
      }, 2200);
    }

    if (result.success && result.isPerfect) {
      if (feedbackTimeoutRef.current) {
        clearTimeout(feedbackTimeoutRef.current);
      }

      if (result.expanded) {
        setFeedback({
          id: Date.now(),
          type: 'mastery',
          title: 'MASTERY! Block Expanded!',
          subText: '+GROW',
        });
      } else {
        const comboText =
          result.combo > 1 ? `Perfect! Combo x${result.combo}` : 'Perfect!';
        setFeedback({
          id: Date.now(),
          type: 'perfect',
          title: comboText,
        });
      }

      feedbackTimeoutRef.current = window.setTimeout(() => {
        setFeedback(null);
      }, 1300);
    }
  }, []);

  // Pause action
  const handlePause = useCallback(() => {
    if (gameState === 'playing') {
      sound.playClick();
      setGameState('paused');
    }
  }, [gameState]);

  // Resume action
  const handleResume = useCallback(() => {
    if (gameState === 'paused') {
      sound.playClick();
      setGameState('playing');
    }
  }, [gameState]);

  // Go to Title action - resets game state and resets 3D scene demo
  const handleGoHome = useCallback(() => {
    sound.playClick();
    if (feedbackTimeoutRef.current) {
      clearTimeout(feedbackTimeoutRef.current);
    }
    if (levelTimeoutRef.current) {
      clearTimeout(levelTimeoutRef.current);
    }
    setFeedback(null);
    setLevelBanner(null);
    setGameState('title');
    if (engineRef.current) {
      engineRef.current.startTitleDemo();
    }
  }, []);

  // Global touch/pointer listener attached to entire window
  useEffect(() => {
    const handleGlobalPointerDown = (e: PointerEvent) => {
      const target = e.target as HTMLElement | null;
      // Never intercept clicks on buttons, inputs, links, or modal controls
      if (
        target &&
        target.closest('button, a, input, select, textarea, [data-interactive="true"]')
      ) {
        return;
      }

      if (gameStateRef.current === 'playing') {
        handlePlaceAction();
      } else if (gameStateRef.current === 'gameover') {
        // Tapping anywhere on the screen during Game Over restarts after brief debounce
        if (Date.now() - gameOverTimeRef.current > 350) {
          handleStartGame();
        }
      }
    };

    window.addEventListener('pointerdown', handleGlobalPointerDown);
    return () => {
      window.removeEventListener('pointerdown', handleGlobalPointerDown);
    };
  }, [handlePlaceAction, handleStartGame]);

  // Keyboard controls listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input field (like player name edit)
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }

      if (e.repeat) return; // Prevent repeated rapid-fire on hold

      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        if (gameState === 'playing') {
          handlePlaceAction();
        } else if (gameState === 'title') {
          handleStartGame();
        } else if (gameState === 'gameover') {
          handleStartGame();
        }
      } else if (e.code === 'Escape' || e.key === 'p' || e.key === 'P') {
        e.preventDefault();
        if (gameState === 'playing') {
          handlePause();
        } else if (gameState === 'paused') {
          handleResume();
        }
      } else if (e.key === 'r' || e.key === 'R') {
        if (gameState === 'playing' || gameState === 'gameover' || gameState === 'paused') {
          e.preventDefault();
          handleStartGame();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, handlePlaceAction, handleStartGame, handlePause, handleResume]);

  // Sound and Haptics toggles
  const handleToggleSound = useCallback(() => {
    const next = !stats.soundEnabled;
    const updated = { ...stats, soundEnabled: next };
    setStats(updated);
    savePlayerStats(updated);
    sound.setMuted(!next);
  }, [stats]);

  const handleToggleHaptics = useCallback(() => {
    const next = !stats.hapticsEnabled;
    const updated = { ...stats, hapticsEnabled: next };
    setStats(updated);
    savePlayerStats(updated);
    sound.setHaptics(next);
  }, [stats]);

  // Theme selection
  const handleSelectTheme = useCallback(
    (themeId: ThemeId) => {
      const updated = { ...stats, activeTheme: themeId };
      setStats(updated);
      savePlayerStats(updated);
      if (engineRef.current) {
        engineRef.current.setTheme(themeId);
      }
    },
    [stats]
  );

  // Style selection
  const handleSelectStyle = useCallback(
    (style: BlockMaterialStyle) => {
      const updated = { ...stats, activeStyle: style };
      setStats(updated);
      savePlayerStats(updated);
      if (engineRef.current) {
        engineRef.current.setStyle(style);
      }
    },
    [stats]
  );

  // Player Name Update
  const handleUpdatePlayerName = useCallback(
    (name: string) => {
      const updated = { ...stats, playerName: name };
      setStats(updated);
      savePlayerStats(updated);
    },
    [stats]
  );

  const leaderboardItems: LeaderboardItem[] = getCombinedLeaderboard(
    stats.highScore,
    stats.playerName
  );

  const activeThemeObj = THEMES[stats.activeTheme] || THEMES.prism;

  return (
    <div
      className="relative w-screen h-screen overflow-hidden select-none bg-slate-950 font-sans"
      style={{
        background: `radial-gradient(circle at 50% 30%, ${activeThemeObj.skyTop} 0%, ${activeThemeObj.skyBottom} 100%)`,
      }}
    >
      {/* Isolated Three.js WebGL Canvas Mount Container */}
      <div
        ref={mountRef}
        className="absolute inset-0 z-0 w-full h-full cursor-pointer select-none"
        style={{ touchAction: 'manipulation' }}
      />

      {/* Screen 1: Title Screen */}
      {gameState === 'title' && (
        <TitleScreen
          highScore={stats.highScore}
          soundEnabled={stats.soundEnabled}
          onToggleSound={handleToggleSound}
          onStartGame={handleStartGame}
          onOpenLeaderboard={() => setShowLeaderboard(true)}
          onOpenThemes={() => setShowThemes(true)}
          onOpenTutorial={() => setShowTutorial(true)}
          activeThemeName={activeThemeObj.name}
          activeStyleName={stats.activeStyle.toUpperCase()}
        />
      )}

      {/* Screen 2: In-Game Low-Occlusion HUD */}
      {gameState === 'playing' && (
        <GameHUD
          score={score}
          highScore={stats.highScore}
          combo={combo}
          soundEnabled={stats.soundEnabled}
          hapticsEnabled={stats.hapticsEnabled}
          onToggleSound={handleToggleSound}
          onToggleHaptics={handleToggleHaptics}
          onPause={handlePause}
          onOpenLeaderboard={() => setShowLeaderboard(true)}
          activeThemeName={activeThemeObj.name}
          feedback={feedback}
          levelBanner={levelBanner}
        />
      )}

      {/* Screen 3: Game Over Modal */}
      {gameState === 'gameover' && (
        <GameOverModal
          score={score}
          highScore={stats.highScore}
          maxCombo={lastMaxCombo}
          perfectCount={lastPerfectCount}
          isNewHigh={isNewHighScore}
          unlockedList={newlyUnlocked}
          onRestart={handleStartGame}
          onGoHome={handleGoHome}
          onShare={() => setShowShare(true)}
          onOpenLeaderboard={() => setShowLeaderboard(true)}
          onOpenThemes={() => setShowThemes(true)}
        />
      )}

      {/* Modal: Pause Screen */}
      {gameState === 'paused' && (
        <PauseModal
          soundEnabled={stats.soundEnabled}
          hapticsEnabled={stats.hapticsEnabled}
          onToggleSound={handleToggleSound}
          onToggleHaptics={handleToggleHaptics}
          onResume={handleResume}
          onRestart={handleStartGame}
          onGoHome={handleGoHome}
          onOpenTutorial={() => setShowTutorial(true)}
        />
      )}

      {/* Modal: Global & Local Leaderboards */}
      {showLeaderboard && (
        <LeaderboardModal
          items={leaderboardItems}
          history={history}
          playerName={stats.playerName}
          onUpdatePlayerName={handleUpdatePlayerName}
          onClose={() => setShowLeaderboard(false)}
        />
      )}

      {/* Modal: Themes, Block Skins & Progression Shop */}
      {showThemes && (
        <ThemeShopModal
          activeTheme={stats.activeTheme}
          activeStyle={stats.activeStyle}
          unlockedThemes={stats.unlockedThemes}
          unlockedStyles={stats.unlockedStyles}
          highScore={stats.highScore}
          totalStacked={stats.totalBlocksStacked}
          highestCombo={stats.highestCombo}
          onSelectTheme={handleSelectTheme}
          onSelectStyle={handleSelectStyle}
          onClose={() => setShowThemes(false)}
        />
      )}

      {/* Modal: Social Sharing & Screenshot Export */}
      {showShare && (
        <ShareModal
          score={score}
          maxCombo={lastMaxCombo}
          perfectCount={lastPerfectCount}
          screenshotUrl={screenshotUrl}
          onClose={() => setShowShare(false)}
        />
      )}

      {/* Modal: How to Play Instructions */}
      {showTutorial && (
        <TutorialModal onClose={() => setShowTutorial(false)} />
      )}
    </div>
  );
}
